﻿using Newtonsoft.Json;
using SEG.ListStartersLibrary.Implementation;
using SEG.ListStartersLibrary.Interfaces;
using SEG.ListStartersLibrary.Models;
using System;
using System.Threading.Tasks;

namespace SEG.ListStartersLibrary.Process
{
    public class ListStartersCacheProcess : IListStartersCacheProcess
    {

        private IListStarters _listStarters;
        RedisDatabaseOperations redisDatabaseOperations = null;

        public ListStartersCacheProcess(IListStarters listStarters)
        {
            _listStarters = listStarters;
            redisDatabaseOperations = new RedisDatabaseOperations();
        }


        public async Task<GetListStartersResponse> GetListStartersAsync(GetListStartersRequest request)
        {
            try
            {
                string cachedRecipeKey = String.Format("GetListStartersAsync {0}", JsonConvert.SerializeObject(request));


                // Implement caching here

                var cacheResponse = redisDatabaseOperations.getCache(cachedRecipeKey);

                if (!cacheResponse.IsNullOrEmpty)
                {
                    return JsonConvert.DeserializeObject<GetListStartersResponse>(cacheResponse);
                }
                else
                {
                    GetListStartersResponse result = await _listStarters.GetListStartersAsync(request).ConfigureAwait(false);

                    redisDatabaseOperations.setCache(JsonConvert.SerializeObject(result), cachedRecipeKey);
                    return result;
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
