﻿using Newtonsoft.Json;
using SEG.ListStartersLibrary.Implementation;
using SEG.ListStartersLibrary.Interfaces;
using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SEG.ListStartersLibrary.Process
{
    public class ListStarterProductsCacheProcess : IListStarterProductsCacheProcess
    {
        private IListStarterProducts _listStarterProducts;
        RedisDatabaseOperations redisDatabaseOperations = null;

        public ListStarterProductsCacheProcess(IListStarterProducts listStarterProducts)
        {
            _listStarterProducts = listStarterProducts;
            redisDatabaseOperations = new RedisDatabaseOperations();
        }


        public async Task<List<ListStarterProducts>> GetListStarterProductsAsync(Guid? listStarterID)
        {
            try
            {
                string cachedRecipeKey = String.Format("GetListStarterProductsAsync {0}", listStarterID.ToString());


                // Implement caching here

                var cacheResponse = redisDatabaseOperations.getCache(cachedRecipeKey);

                if (!cacheResponse.IsNullOrEmpty)
                {
                    return JsonConvert.DeserializeObject<List<ListStarterProducts>>(cacheResponse);
                }
                else
                {
                    List<ListStarterProducts> result = await _listStarterProducts.GetListStarterProductsAsync(listStarterID).ConfigureAwait(false);

                    redisDatabaseOperations.setCache(JsonConvert.SerializeObject(result), cachedRecipeKey);
                    return result;
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
