﻿using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEG.ListStartersLibrary.Interfaces
{
    public interface IListStarterProductsCacheProcess
    {
        public Task<List<ListStarterProducts>> GetListStarterProductsAsync(Guid? listStarterID);

    }
}
