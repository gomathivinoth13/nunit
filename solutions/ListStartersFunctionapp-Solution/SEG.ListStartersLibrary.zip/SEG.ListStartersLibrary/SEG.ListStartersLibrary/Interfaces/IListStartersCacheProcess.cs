﻿using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEG.ListStartersLibrary.Interfaces
{
    public interface IListStartersCacheProcess
    {
        public Task<GetListStartersResponse> GetListStartersAsync(GetListStartersRequest request);
    }
}
