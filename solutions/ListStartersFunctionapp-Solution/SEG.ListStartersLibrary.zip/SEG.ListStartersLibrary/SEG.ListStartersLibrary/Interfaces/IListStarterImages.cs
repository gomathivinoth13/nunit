﻿using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SEG.ListStartersLibrary.Interfaces
{
    public interface IListStarterImages
    {
        public Task<List<ListStarterImages>> GetListStarterImagesAsync(List<Guid?> listStarterIDs);

        public Task<bool> SaveListStarterImagesAsync(List<ListStarterImages> listStarterImages);
    }
}
