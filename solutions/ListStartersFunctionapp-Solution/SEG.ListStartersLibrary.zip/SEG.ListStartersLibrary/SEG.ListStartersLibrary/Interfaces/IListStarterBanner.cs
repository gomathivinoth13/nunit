﻿using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SEG.ListStartersLibrary.Interfaces
{
    public interface IListStarterBanner
    {
        public Task<List<ListStarterBanner>> GetListStarterBannerAsync(Guid? listStarterID);

        public Task<bool> SaveListStarterBannerAsync(List<ListStarterBanner> listStarterBanners);
    }
}
