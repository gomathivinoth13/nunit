﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Text;

namespace SEG.ListStartersLibrary.Implementation
{
    public class RedisConnectorHelper : ConfigurationDAL
    {
        static string _localHost;
        private IDatabase redisCache;
        private bool IsInitialized;

        private StackExchange.Redis.IDatabase _cache;
        private bool _cacheAvailable;

        public static string localHost
        {
            get
            {
                return _localHost;
            }

            set
            {
                _localHost = value;
            }
        }
        static RedisConnectorHelper()
        {
            RedisConnectorHelper.lazyConnection = new Lazy<ConnectionMultiplexer>(() =>
            {
                ConnectionMultiplexer.SetFeatureFlag("preventthreadtheft", true);
                return ConnectionMultiplexer.Connect(localHost);
            });
        }

        private static Lazy<ConnectionMultiplexer> lazyConnection;

        public static ConnectionMultiplexer Connection
        {
            get
            {
                return lazyConnection.Value;
            }
        }


        public IDatabase CachedRepository()
        {
            if (Connection.IsConnected)
            {
                redisCache = Connection.GetDatabase();
                IsInitialized = true;
            }
            else
            {
                redisCache = null;
                IsInitialized = false;
            }

            return redisCache;
        }

        public bool RedisAvailable()
        {
            return IsInitialized;
        }
    }
}
