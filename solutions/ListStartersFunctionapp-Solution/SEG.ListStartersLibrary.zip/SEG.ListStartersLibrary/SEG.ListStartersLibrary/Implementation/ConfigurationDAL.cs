﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEG.ListStartersLibrary.Implementation
{
    public class ConfigurationDAL
    {
        //protected string _connectionString = "Server=az-sql-digitalmktg-dev1.database.windows.net,1433;Initial Catalog=AZ_ListStarters_Dev;Persist Security Info=False;User ID=ListStarters_App_Dev;Password=LStarts$PWD;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

        protected string _connectionString = Environment.GetEnvironmentVariable("DataBaseConnectionString");

        public ConfigurationDAL()
        {
            //RedisConnectorHelper.localHost = "redis-liststarters-cache-dev-001.redis.cache.windows.net:6380,password=K7ozWYJY0DOSXFoT6nsWPUOdowv4LcxyOAzCaBPyNKk=,ssl=True,abortConnect=False";

            RedisConnectorHelper.localHost = Environment.GetEnvironmentVariable("RedisConnectionString");
        }
    }
}
