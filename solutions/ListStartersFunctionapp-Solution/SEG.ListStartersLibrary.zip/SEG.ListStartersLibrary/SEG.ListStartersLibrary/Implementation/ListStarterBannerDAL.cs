﻿using Dapper;
using SEG.ListStartersLibrary.Interfaces;
using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace SEG.ListStartersLibrary.Implementation
{
    public class ListStarterBannerDAL : ConfigurationDAL, IListStarterBanner
    {
        public async Task<List<ListStarterBanner>> GetListStarterBannerAsync(Guid? listStarterID)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    var sqlStatement = string.Format(@"
                            SELECT * FROM ListStarterBanner with (nolock)
                           where ListStarterID = '{0}'", listStarterID);

                    var listStarterBanner = connection.Query<ListStarterBanner>(sqlStatement);

                    if (listStarterBanner == null)
                    {
                        return new List<ListStarterBanner>();
                    }
                    else
                    {
                        return listStarterBanner.ToList();
                    }
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }


        public async Task<bool> SaveListStarterBannerAsync(List<ListStarterBanner> listStarterBanners)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    using (var connection = new SqlConnection(_connectionString))
                    {
                        await connection.OpenAsync();
                        foreach (var listStarterBanner in listStarterBanners)
                        {
                            string sqlStatement = @"IF EXISTS(SELECT * FROM dbo.ListStarterBanner WITH (NOLOCK) WHERE ListStarterID = @ListStarterID and BannerID = @BannerID )
                              UPDATE dbo.ListStarterBanner
                                 SET  IsActive = @IsActive
                               WHERE ListStarterID = @ListStarterID and BannerID = @BannerID ;
                            ELSE
                                       INSERT INTO dbo.ListStarterBanner(ListStarterID, BannerID, IsActive)
                                                    VALUES(@ListStarterID, @BannerID, @IsActive)";
                            await connection.ExecuteScalarAsync(sqlStatement, listStarterBanner);
                        }
                    }
                    scope.Complete();
                }
                return true;

            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
    }
}
