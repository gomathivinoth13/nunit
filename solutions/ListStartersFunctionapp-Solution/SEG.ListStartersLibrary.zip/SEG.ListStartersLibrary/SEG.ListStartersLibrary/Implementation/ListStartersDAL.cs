﻿using Dapper;
using SEG.ListStartersLibrary.Interfaces;
using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace SEG.ListStartersLibrary.Implementation
{
    public class ListStartersDAL : ConfigurationDAL, IListStarters
    {
        const int DefaultPaginationLimit = 20;
        public async Task<GetListStartersResponse> GetListStartersAsync(GetListStartersRequest request)
        {
            GetListStartersResponse response = new GetListStartersResponse();
            List<ListStarters> listStarters = new List<ListStarters>();
            List<ListStarterImages> images = null;

            try
            {

                string sql = string.Empty;


                sql = @"SELECT distinct ls.*,COUNT(*) OVER () as totalCount  
                       FROM ListStarters as ls with(nolock)
                       join ListStarterBanner as lsb with(nolock) on ls.ListStarterID = lsb.ListStarterID
                       where ls.IsActive = 1 and lsb.IsActive =1 ";


                StringBuilder sqlbuilder = new StringBuilder(sql);


                if (request.BannerID != 0)
                {
                    sqlbuilder.Append(string.Format(" and lsb.BannerID = '{0}'", request.BannerID));
                }

                if (request.ListStarterID.HasValue)
                {
                    sqlbuilder.Append(string.Format(" and ls.ListStarterID = '{0}'", request.ListStarterID));
                }

                //if (request.IsFeatured)
                //{
                //    sqlbuilder.Append(string.Format(" and ls.IsFeatured = 1 "));
                //}

                sqlbuilder.Append(string.Format(" order by ls.DateAdded DESC "));

                if (request.PaginationLimit == 0 || request.PaginationLimit > 20)
                {
                    request.PaginationLimit = DefaultPaginationLimit;
                    response.PaginationLimit = DefaultPaginationLimit;
                }
                else
                {
                    response.PaginationLimit = request.PaginationLimit;
                }
                response.PaginationOffset = request.PaginationOffset;
                response.SortOrder = request.SortOrder;

                sqlbuilder.Append(string.Format(" offset {0} rows fetch next {1} rows only ", response.PaginationOffset, response.PaginationLimit));

                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    listStarters = connection.Query<ListStarters>(sqlbuilder.ToString()).ToList();
                }

                if (listStarters == null || listStarters.Count() <= 0)
                {
                    return response;
                }
                else
                {
                    var ids = listStarters.Select(x => x.ListStarterID).ToList();

                    if (ids != null && ids.Count > 0)
                    {
                        ListStarterImagesDAL imageDal = new ListStarterImagesDAL();

                        images = await imageDal.GetListStarterImagesAsync(ids).ConfigureAwait(false);
                    }

                    foreach (var i in listStarters)
                    {
                        i.listStarterImages = images.Where(s => s.ListStarterID == i.ListStarterID).ToList();
                    }

                    response.TotalCount = listStarters.First().TotalCount;
                    response.ResultCount = listStarters.Count();
                    response.listStarters = listStarters;
                }
                return response;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public async Task<bool> SaveListStartersAsync(List<ListStarters> listStarters)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    using (var connection = new SqlConnection(_connectionString))
                    {
                        await connection.OpenAsync();
                        foreach (var listStarter in listStarters)
                        {
                            string sqlStatement = @"IF EXISTS(SELECT * FROM dbo.ListStarters WITH (NOLOCK) WHERE ListStarterID = @ListStarterID)
                              UPDATE dbo.ListStarters
                                 SET ListStarterTitle = @ListStarterTitle,ListStarterSpanishTitle = @ListStarterSpanishTitle ,ListStarterSubTitle = @ListStarterSubTitle , ListStarterSpanishSubTitle = @ListStarterSpanishSubTitle ,ListStarterDescription=@ListStarterDescription ,ListStarterSpanishDescription = @ListStarterSpanishDescription, IsCarouselDisplay = @IsCarouselDisplay,DateModified = getdate(), IsActive = @IsActive
                               WHERE ListStarterID = @ListStarterID;
                            ELSE
                                       INSERT INTO dbo.ListStarters(ListStarterID, ListStarterTitle,ListStarterSpanishTitle,ListStarterSubTitle,ListStarterSpanishSubTitle,ListStarterDescription,ListStarterSpanishDescription,IsCarouselDisplay,DateAdded,DateModified, IsActive)
                                                    VALUES(@ListStarterID, @ListStarterTitle, @ListStarterSpanishTitle, @ListStarterSubTitle, @ListStarterSpanishSubTitle,@ListStarterDescription,@ListStarterSpanishDescription,@IsCarouselDisplay,getdate(),getdate(), @IsActive)";
                            await connection.ExecuteScalarAsync(sqlStatement, listStarter);
                        }
                    }

                    scope.Complete();
                }
                return true;

            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
    }
}
