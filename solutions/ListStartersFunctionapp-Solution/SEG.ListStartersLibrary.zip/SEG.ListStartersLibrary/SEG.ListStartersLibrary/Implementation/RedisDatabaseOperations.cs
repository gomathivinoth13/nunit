﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Text;

namespace SEG.ListStartersLibrary.Implementation
{
    public class RedisDatabaseOperations : RedisConnectorHelper
    {
        private StackExchange.Redis.IDatabase _cache;
        private bool _cacheAvailable;


        public RedisDatabaseOperations()
        {
            _cache = CachedRepository();
            _cacheAvailable = RedisAvailable();
        }

        public RedisValue getCache(string key)
        {
            if (_cacheAvailable)
                return _cache.StringGet(key);
            else
                return string.Empty;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="serializedObject"></param>
        /// <param name="key"></param>
        public void setCache(string serializedObject, string key)
        {
            try
            {
                TimeSpan ttc = new TimeSpan(6, 0, 0);
                if (ttc.Ticks > 0)
                {
                    if (_cacheAvailable)
                        _cache.StringSetAsync(key, serializedObject, ttc);
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
