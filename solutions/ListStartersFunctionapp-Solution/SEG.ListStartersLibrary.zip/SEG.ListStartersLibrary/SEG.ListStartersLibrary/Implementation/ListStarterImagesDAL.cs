﻿using Dapper;
using SEG.ListStartersLibrary.Interfaces;
using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace SEG.ListStartersLibrary.Implementation
{
    public class ListStarterImagesDAL : ConfigurationDAL, IListStarterImages
    {
        public async Task<List<ListStarterImages>> GetListStarterImagesAsync(List<Guid?> listStarterIDs)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    var sqlStatement = string.Format(@"
                            SELECT * FROM ListStarterImages with (nolock) where ListStarterID IN ( {0} )", ArrayToString(listStarterIDs));

                    var images = connection.Query<ListStarterImages>(sqlStatement);

                    if (images == null)
                    {
                        return new List<ListStarterImages>();
                    }
                    else
                    {
                        return images.ToList();
                    }
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }

        public async Task<bool> SaveListStarterImagesAsync(List<ListStarterImages> listStarterImages)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    using (var connection = new SqlConnection(_connectionString))
                    {
                        await connection.OpenAsync();
                        foreach (var listStarterImage in listStarterImages)
                        {
                            string sqlStatement = @"IF EXISTS(SELECT * FROM dbo.ListStarterImages WITH (NOLOCK) WHERE ListStarterImageID = @ListStarterImageID)
                              UPDATE dbo.ListStarterImages
                                 SET ListStarterImageID = @ListStarterImageID,ListStarterImageURL = @ListStarterImageURL , IsActive = @IsActive
                               WHERE ListStarterImageID = @ListStarterImageID;
                            ELSE
                                       INSERT INTO dbo.ListStarterImages(ListStarterID, ListStarterImageID,ListStarterImageURL, IsActive)
                                                    VALUES(@ListStarterID, @ListStarterImageID, @ListStarterImageURL,@IsActive)";
                            await connection.ExecuteScalarAsync(sqlStatement, listStarterImage);
                        }
                    }

                    scope.Complete();
                }
                return true;

            }
            catch (Exception exception)
            {
                throw exception;
            }

        }

        private static string ArrayToString(IEnumerable<Guid?> array)
        {
            var result = new StringBuilder();

            foreach (Guid element in array)
            {
                if (result.Length > 0)
                {
                    result.Append(", ");
                }
                result.Append("'");
                result.Append(element);
                result.Append("'");
            }
            return result.ToString();
        }
    }
}

