﻿using Dapper;
using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SEG.ListStartersLibrary.Interfaces;
using System.Transactions;

namespace SEG.ListStartersLibrary.Implementation
{
    public class ListStarterProductsDAL : ConfigurationDAL, IListStarterProducts
    {
        public async Task<List<ListStarterProducts>> GetListStarterProductsAsync(Guid? listStarterID)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync();

                    var sqlStatement = string.Format(@"
                            SELECT lsp.* FROM ListStarterProducts as lsp with (nolock)
                           where lsp.ListStarterID= '{0}' order by lsp.ItemSeqNum ", listStarterID);

                    var recipeIngredients = connection.Query<ListStarterProducts>(sqlStatement);

                    if (recipeIngredients == null)
                    {
                        return new List<ListStarterProducts>();
                    }
                    else
                    {
                        return recipeIngredients.ToList();
                    }
                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }


        public async Task<bool> SaveListStarterProductsAsync(List<ListStarterProducts> listStarterProducts)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    using (var connection = new SqlConnection(_connectionString))
                    {
                        await connection.OpenAsync();
                        foreach (var listStarterProduct in listStarterProducts)
                        {
                            string sqlStatement = @"IF EXISTS(SELECT * FROM dbo.ListStarterProducts WITH (NOLOCK) WHERE ListStarterProductID = @ListStarterProductID)
                              UPDATE dbo.ListStarterProducts
                                 SET ListStarterProductID = @ListStarterProductID,ListStarterWDCode = @ListStarterWDCode ,ListStarterUPC = @ListStarterUPC , ItemSeqNum = @ItemSeqNum,IsActive = @IsActive
                               WHERE ListStarterProductID = @ListStarterProductID;
                            ELSE
                                       INSERT INTO dbo.ListStarterProducts(ListStarterID, ListStarterProductID,ListStarterWDCode,ListStarterUPC,ItemSeqNum, IsActive)
                                                    VALUES(@ListStarterID, @ListStarterProductID, @ListStarterWDCode, @ListStarterUPC, @ItemSeqNum, @IsActive)";

                            await connection.ExecuteScalarAsync(sqlStatement, listStarterProduct);
                        }
                    }

                    scope.Complete();
                }
                return true;
            }
            catch (Exception exception)
            {
                throw exception;
            }
        }
    }
}
