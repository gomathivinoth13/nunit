﻿using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace SEG.ListStartersLibrary.Implementation
{
    public class Utility
    {
        //
        public ListStartersFailureResponse statusCode(Exception e)
        {
            return (new ListStartersFailureResponse
            {
                ErrorDescription = e.Message,
                ErrorCode = (e.Data["ErrorCode"] != null) ? e.Data["ErrorCode"].ToString() : "5000",
            });
        }
    }
}
