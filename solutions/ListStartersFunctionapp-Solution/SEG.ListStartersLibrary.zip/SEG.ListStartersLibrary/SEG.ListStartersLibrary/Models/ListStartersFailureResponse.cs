﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace SEG.ListStartersLibrary.Models
{
    public class ListStartersFailureResponse
    {
        //
        // Summary:
        //     Gets or sets the error code.

        [JsonProperty(PropertyName = "errorMessage", NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorCode { get; set; }
        //
        // Summary:
        //     Gets or sets information describing the error.

        [JsonProperty(PropertyName = "errorDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string ErrorDescription { get; set; }


        [JsonProperty(PropertyName = "details", NullValueHandling = NullValueHandling.Ignore)]
        public List<string> Details { get; set; }
    }
}
