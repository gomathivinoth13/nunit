﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace SEG.ListStartersLibrary.Models
{
    public class ListStarterImages
    {
        [JsonProperty(PropertyName = "listStarterID", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? ListStarterID { get; set; }


        [JsonProperty(PropertyName = "listStarterImageID", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? ListStarterImageID { get; set; }

        [JsonProperty(PropertyName = "listStarterImageURL", NullValueHandling = NullValueHandling.Ignore)]
        public string ListStarterImageURL { get; set; }

        [JsonProperty(PropertyName = "isActive", NullValueHandling = NullValueHandling.Ignore)]
        public bool IsActive { get; set; }
    }
}
