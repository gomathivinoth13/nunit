﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace SEG.ListStartersLibrary.Models
{
    public class GetListStartersRequest : Pagination
    {
        [JsonProperty(PropertyName = "listStarterID", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? ListStarterID { get; set; }


        [JsonProperty(PropertyName = "bannerID", NullValueHandling = NullValueHandling.Ignore)]
        public int BannerID { get; set; }

        //[JsonProperty(PropertyName = "isFeatured", NullValueHandling = NullValueHandling.Ignore)]
        //public bool IsFeatured { get; set; }
    }
}
