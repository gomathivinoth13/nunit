﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;


namespace SEG.ListStartersLibrary.Models
{
    public class ListStarterBanner
    {
        [JsonProperty(PropertyName = "listStarterID", NullValueHandling = NullValueHandling.Ignore)]
        public string ListStarterID { get; set; }

        [JsonProperty(PropertyName = "bannerID", NullValueHandling = NullValueHandling.Ignore)]
        public int BannerID { get; set; }

        [JsonProperty(PropertyName = "isActive", NullValueHandling = NullValueHandling.Ignore)]
        public bool IsActive { get; set; }
    }
}
