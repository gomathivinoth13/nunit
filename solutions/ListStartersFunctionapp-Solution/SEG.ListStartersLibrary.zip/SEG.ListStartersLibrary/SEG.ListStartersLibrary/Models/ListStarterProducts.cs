﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;


namespace SEG.ListStartersLibrary.Models
{
    public class ListStarterProducts
    {
        [JsonProperty(PropertyName = "listStarterID", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? ListStarterID { get; set; }

        [JsonProperty(PropertyName = "listStarterProductID", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? ListStarterProductID { get; set; }

        [JsonProperty(PropertyName = "listStarterWDCode", NullValueHandling = NullValueHandling.Ignore)]
        public int ListStarterWDCode { get; set; }

        [JsonProperty(PropertyName = "listStarterUPC", NullValueHandling = NullValueHandling.Ignore)]
        public string ListStarterUPC { get; set; }


        [JsonProperty(PropertyName = "itemSeqNum", NullValueHandling = NullValueHandling.Ignore)]
        public int ItemSeqNum { get; set; }

        [JsonProperty(PropertyName = "isActive", NullValueHandling = NullValueHandling.Ignore)]
        public bool IsActive { get; set; }

    }
}
