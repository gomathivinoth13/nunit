﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace SEG.ListStartersLibrary.Models
{
    public class GetListStartersResponse : Pagination
    {

        [JsonProperty(PropertyName = "totalCount", NullValueHandling = NullValueHandling.Ignore)]
        public int TotalCount { get; set; }

        [JsonProperty(PropertyName = "resultCount", NullValueHandling = NullValueHandling.Ignore)]
        public int ResultCount { get; set; }

        [JsonProperty(PropertyName = "listStarters", NullValueHandling = NullValueHandling.Ignore)]
        public List<ListStarters> listStarters { get; set; }
    }
}
