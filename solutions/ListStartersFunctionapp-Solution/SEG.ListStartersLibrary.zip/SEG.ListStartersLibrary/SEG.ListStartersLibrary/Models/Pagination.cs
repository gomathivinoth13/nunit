﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace SEG.ListStartersLibrary.Models
{
    public class Pagination
    {
        [JsonProperty(PropertyName = "sortOrder", NullValueHandling = NullValueHandling.Ignore)]
        public string SortOrder { get; set; }

        [JsonProperty(PropertyName = "paginationLimit", NullValueHandling = NullValueHandling.Ignore)]
        public int PaginationLimit { get; set; }

        [JsonProperty(PropertyName = "paginationOffset", NullValueHandling = NullValueHandling.Ignore)]
        public int PaginationOffset { get; set; }
    }
}
