﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;


namespace SEG.ListStartersLibrary.Models
{
    public class ListStarters
    {
        [JsonProperty(PropertyName = "listStarterID", NullValueHandling = NullValueHandling.Ignore)]
        public Guid? ListStarterID { get; set; }

        [JsonProperty(PropertyName = "listStarterTitle", NullValueHandling = NullValueHandling.Ignore)]
        public string ListStarterTitle { get; set; }

        [JsonProperty(PropertyName = "listStarterSpanishTitle", NullValueHandling = NullValueHandling.Ignore)]
        public string ListStarterSpanishTitle { get; set; }

        [JsonProperty(PropertyName = "listStarterSubTitle", NullValueHandling = NullValueHandling.Ignore)]
        public string ListStarterSubTitle { get; set; }

        [JsonProperty(PropertyName = "listStarterSpanishSubTitle", NullValueHandling = NullValueHandling.Ignore)]
        public string ListStarterSpanishSubTitle { get; set; }

        [JsonProperty(PropertyName = "listStarterDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string ListStarterDescription { get; set; }

        [JsonProperty(PropertyName = "listStarterSpanishDescription", NullValueHandling = NullValueHandling.Ignore)]
        public string ListStarterSpanishDescription { get; set; }

        [JsonProperty(PropertyName = "isCarouselDisplay", NullValueHandling = NullValueHandling.Ignore)]
        public bool IsCarouselDisplay { get; set; }

        //[JsonProperty(PropertyName = "isFeatured", NullValueHandling = NullValueHandling.Ignore)]
        //public bool IsFeatured { get; set; }

        [JsonProperty(PropertyName = "isActive", NullValueHandling = NullValueHandling.Ignore)]
        public bool IsActive { get; set; }

        [JsonProperty(PropertyName = "dateAdded", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime DateAdded { get; set; }

        [JsonProperty(PropertyName = "dateModified", NullValueHandling = NullValueHandling.Ignore)]
        public DateTime DateModified { get; set; }

        [JsonProperty(PropertyName = "listStarterImages", NullValueHandling = NullValueHandling.Ignore)]
        public List<ListStarterImages> listStarterImages { get; set; }

        [JsonProperty(PropertyName = "totalCount", NullValueHandling = NullValueHandling.Ignore)]
        public int TotalCount { get; set; }

    }
}
