﻿using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using SEG.ListStartersLibrary.Interfaces;
using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using ListStartersFunctionApp.ExtensionMethods;
using ListStartersFunctionApp.Models;
using Microsoft.Azure.Functions.Worker.Extensions.OpenApi.Extensions;

namespace ListStartersFunctionApp.Functions
{
    public class ListStarterProductsFunction
    {
        private readonly IListStarterProducts _listStarterProducts;
        private readonly ILogger<ListStarterProductsFunction> _log;
        private readonly IListStarterProductsCacheProcess _listStarterProductsCacheProcess;

        public ListStarterProductsFunction(IListStarterProducts listStarterProducts, ILogger<ListStarterProductsFunction> logger, IListStarterProductsCacheProcess listStarterProductsCacheProcess)
        {
            _listStarterProducts = listStarterProducts ?? throw new ArgumentNullException(nameof(listStarterProducts));
            _log = logger ?? throw new ArgumentNullException(nameof(logger)); ;
            _listStarterProductsCacheProcess = listStarterProductsCacheProcess ?? throw new ArgumentNullException(nameof(listStarterProductsCacheProcess));
        }

        [OpenApiOperation(operationId: "Get_GetListStarterProducts", Summary = "", Description = "Get ListStarter Products")]
        [OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/text", bodyType: typeof(List<ListStarterProducts>), Description = "")]
        [OpenApiResponseWithBody(HttpStatusCode.InternalServerError, contentType: "application/json", bodyType: typeof(ListStartersFailureResponse))]
        [OpenApiResponseWithBody(HttpStatusCode.BadRequest, contentType: "application/json", bodyType: typeof(ListStartersFailureResponse))]
        [Function(nameof(GetListStarterProducts))]
        public async Task<HttpResponseData> GetListStarterProducts(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "Starters/GetListStarterProducts")]
            HttpRequestData req)
        {

            try
            {
                _log.LogInformation(ResponseMessage.LogInfo);

                if (!Guid.TryParse(req.Query("listStarterID").ToString(), out Guid listStarterID))
                    return await req.SetHttpFailureResponseAsync(HttpStatusCode.BadRequest, ResponseMessage.Invalid);

                var result = await _listStarterProductsCacheProcess.GetListStarterProductsAsync(listStarterID);

                if (result is null)
                {
                    _log.LogWarning(ResponseMessage.ErrorMessage);
                    return await req.SetHttpFailureResponseAsync(HttpStatusCode.BadRequest, ResponseMessage.ErrorMessage);
                }

                var response = req.CreateResponse(HttpStatusCode.OK);
                await response.WriteAsJsonAsync(result);
                return response;
            }
            catch (Exception e)
            {
                _log.LogError(e, ResponseMessage.ErrorMessage);
                return await req.SetHttpFailureResponseAsync(HttpStatusCode.InternalServerError, e.Message);
            }
        }

        [OpenApiOperation(operationId: "Post_SaveListStarterProducts", Summary = "", Description = "Save ListStarter Products")]
        [OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(List<ListStarterProducts>), Description = "Save ListStarter Products", Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/text", bodyType: typeof(bool), Description = "")]
        [OpenApiResponseWithBody(HttpStatusCode.InternalServerError, contentType: "application/json", bodyType: typeof(ListStartersFailureResponse))]
        [OpenApiResponseWithBody(HttpStatusCode.BadRequest, contentType: "application/json", bodyType: typeof(ListStartersFailureResponse))]
        [Function(nameof(SaveListStarterProducts))]
        public async Task<HttpResponseData> SaveListStarterProducts(
           [HttpTrigger(AuthorizationLevel.Function, "post", Route = "Starters/SaveListStarterProducts")]
           HttpRequestData req)
        {
            try
            {     
                if (req.Body.Length == 0)
                {
                    _log.LogWarning(ResponseMessage.NullErrorMessage);
                    return await req.SetHttpFailureResponseAsync(HttpStatusCode.BadRequest, ResponseMessage.NullErrorMessage);
                }

                var request = await req.ReadFromJsonAsync<List<ListStarterProducts>>();

                var result = await _listStarterProducts.SaveListStarterProductsAsync(request);

                if (!result)
                {
                    _log.LogWarning(ResponseMessage.ErrorMessage);
                    return await req.SetHttpFailureResponseAsync(HttpStatusCode.BadRequest, ResponseMessage.ErrorMessage);
                }

                var response = req.CreateResponse(HttpStatusCode.Created);
                await response.WriteAsJsonAsync(result);
                return response;
            }
            catch (Exception e)
            {
                _log.LogError(e, ResponseMessage.ErrorMessage);
                return await req.SetHttpFailureResponseAsync(HttpStatusCode.InternalServerError, e.Message);
            }
        }
    }
}
