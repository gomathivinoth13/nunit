﻿using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using SEG.ListStartersLibrary.Interfaces;
using SEG.ListStartersLibrary.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using ListStartersFunctionApp.ExtensionMethods;
using ListStartersFunctionApp.Models;

namespace ListStartersFunctionApp.Functions
{
    public class ListStarterBannerFunction
    {
        private readonly IListStarterBanner _listStarterBanner;
        private readonly ILogger<ListStarterBannerFunction> _log;
       
        public ListStarterBannerFunction(IListStarterBanner listStarterBanner, ILogger<ListStarterBannerFunction> logger)
        {
            _listStarterBanner = listStarterBanner ?? throw new ArgumentNullException(nameof(listStarterBanner)); ;
            _log = logger ?? throw new ArgumentNullException(nameof(logger)); ;
        }

        [OpenApiOperation(operationId: "Post_SaveListStarterBanner", Summary = "", Description = "Save ListStarter Banner")]
        [OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(List<ListStarterBanner>), Description = "Save ListStarter Banner", Required = true)]
        [OpenApiResponseWithBody(statusCode: HttpStatusCode.OK, contentType: "application/text", bodyType: typeof(bool), Description = "")]
        [OpenApiResponseWithBody(HttpStatusCode.InternalServerError, contentType: "application/json", bodyType: typeof(ListStartersFailureResponse))]
        [OpenApiResponseWithBody(HttpStatusCode.BadRequest, contentType: "application/json", bodyType: typeof(ListStartersFailureResponse))]
        [Function(nameof(SaveListStarterBanner))]
        public async Task<HttpResponseData> SaveListStarterBanner(
            [HttpTrigger(AuthorizationLevel.Function, "post", Route = "Starters/SaveListStarterBanner")]
             HttpRequestData req)
        {
            try
            {
                _log.LogInformation(ResponseMessage.LogInfo);

                if (req.Body.Length == 0)
                {
                    _log.LogWarning(ResponseMessage.NullErrorMessage);
                    return await req.SetHttpFailureResponseAsync(HttpStatusCode.BadRequest, ResponseMessage.NullErrorMessage);
                }

                var request = await req.ReadFromJsonAsync<List<ListStarterBanner>>();
              
                var result = await _listStarterBanner.SaveListStarterBannerAsync(request);

                if (!result)
                {
                    _log.LogWarning(ResponseMessage.ErrorMessage);
                    return await req.SetHttpFailureResponseAsync(HttpStatusCode.BadRequest, ResponseMessage.ErrorMessage);
                }

                var response = req.CreateResponse(HttpStatusCode.Created);
                await response.WriteAsJsonAsync(result);
                return response;
            }
            catch (Exception e)
            {
                _log.LogError(e, ResponseMessage.ErrorMessage);
                return await req.SetHttpFailureResponseAsync(HttpStatusCode.InternalServerError, e.Message);
            }
        }
    }
}
