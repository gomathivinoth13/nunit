﻿
namespace ListStartersFunctionApp.Models
{
    internal static class ResponseMessage
    {
        internal static readonly string SuccessMessage = "Data Inserted Successfully";
        internal static readonly string ErrorMessage = "Error Occured While processing the request";
        internal static readonly string NullErrorMessage = "Input was null, Can't process the request";
        internal static readonly string LogInfo = "Process started!!";
        internal static readonly string Invalid = "Invalid value entered. Please provide a valid value";
    }
}
