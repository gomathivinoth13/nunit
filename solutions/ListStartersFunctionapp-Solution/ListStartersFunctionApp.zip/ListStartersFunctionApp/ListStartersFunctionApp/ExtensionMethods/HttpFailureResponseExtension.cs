﻿using Microsoft.Azure.Functions.Worker.Http;
using SEG.ListStartersLibrary.Models;
using System.Net;
using System.Threading.Tasks;

namespace ListStartersFunctionApp.ExtensionMethods
{
    public static class HttpFailureResponseExtension
    {
       public static async Task<HttpResponseData> SetHttpFailureResponseAsync(this HttpRequestData request, HttpStatusCode code, string message)
        {
            var listStartersFailureResponse = new ListStartersFailureResponse()
            {
                ErrorCode = code!=0 ? code.ToString() : "5000",
                ErrorDescription = message
            };

            HttpResponseData response = request.CreateResponse(code);
            await response.WriteAsJsonAsync(listStartersFailureResponse);
            return response;
        }
    }
}
