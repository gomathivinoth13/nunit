﻿using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Extensions.OpenApi.Extensions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using SEG.ListStartersLibrary.Implementation;
using SEG.ListStartersLibrary.Interfaces;
using SEG.ListStartersLibrary.Process;
using System.Threading.Tasks;

namespace ListStartersFunctionApp
{
    public class Program
    {
        public static async Task Main()
        {
            var host = new HostBuilder()
                 .ConfigureFunctionsWorkerDefaults(builder =>
                 {
                     builder
                         .AddApplicationInsights()
                         .AddApplicationInsightsLogger();
                 })

                 .ConfigureServices(service =>
                 {
                     service.AddTransient<IListStarterProducts, ListStarterProductsDAL>();
                     service.AddTransient<IListStarters, ListStartersDAL>();
                     service.AddTransient<IListStarterBanner, ListStarterBannerDAL>();
                     service.AddTransient<IListStarterImages, ListStarterImagesDAL>();
                     service.AddTransient<IListStarterProductsCacheProcess, ListStarterProductsCacheProcess>();
                     service.AddTransient<IListStartersCacheProcess, ListStartersCacheProcess>();
                 })

                .ConfigureOpenApi()
                .Build();

            await host.RunAsync();
        }
    }
}
