﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections;
using SalesForceLibrary.Models;
using SEG.ApiService.Models;
using SEG.ApiService.Models.SalesForce;
using SEG.SalesForce.Models;
using SEG.ApiService.Models.SendGrid;
using SEG.ApiService.Models.Reminder;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using System.Net;
using Microsoft.OpenApi.Models;
using SEG.ApiService.Models.Pii;
using AzureLoyaltyFunctionApp.BusinessLogic;

namespace AzureLoyaltyFunctionApp
{
    public class AzureLoyaltyFunction_SalesForce
    {
        static IDictionary _cnf = null;
        static AzureLoyaltyFunction_SalesForce()
        {
            _cnf = ConfigSettings.GetConfig();
        }
        private readonly SalesForce _salesForce = new SalesForce(_cnf);


        [FunctionName("DeleteSFMCContact")]
        [OpenApiOperation(operationId: "DeleteSFMCContact", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(string), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(ContactResponse))]
        public Task<ContactResponse> DeleteSFMCContact(
        [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "SalesForce/DeleteSFMCContact")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/DeleteSFMCContact request");
                string memberId = req.Query["memberId"].ToString();
                var response = _salesForce.DeleteSFMCContact(memberId);
               // var response = await new BusinessLogic.SalesForce(_cnf).DeleteSFMCContact(memberId);
                return response;
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/DeleteSFMCContact method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("UpsertAsync")]
        [OpenApiOperation(operationId: "Upsert_Async", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiParameter(name: "opt_Out", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(DataExtentionsRequestInsert), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(DataExtentionsResponse))]
        public async Task<DataExtentionsResponse> UpsertAsync(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/UpsertAsync")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/UpsertAsync request");

                string qryOptOut = req.Query["opt_Out"].ToString();
                bool optOut = (qryOptOut == "1" || qryOptOut.ToUpper() == "TRUE");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var dataExtentionsRequestInsert = JsonConvert.DeserializeObject<DataExtentionsRequestInsert>(requestBody);

                return await _salesForce.UpsertAsync(dataExtentionsRequestInsert, optOut);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/UpsertAsync method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("QueueProcess")]
        [OpenApiOperation(operationId: "Queue_Process", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SalesForceQueueRequest), Description = "", Required = true)]
        [OpenApiResponseWithoutBody(HttpStatusCode.OK)]
        public async Task<IActionResult> QueueProcess(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/QueueProcess")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/QueueProcess request");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var salesForceQueueRequest = JsonConvert.DeserializeObject<SalesForceQueueRequest>(requestBody);

                //await new BusinessLogic.SalesForce(_cnf).QueueProcess(salesForceQueueRequest);
                await _salesForce.QueueProcess(salesForceQueueRequest);
                return new OkResult();
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/QueueProcess method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("Send")]
        [OpenApiOperation(operationId: "Send", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiParameter(name: "messageKey", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiParameter(name: "banner", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(Messaging), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(MessagingResponse))]
        public async Task<MessagingResponse> Send(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/Send")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/Send request");

                string messageKey = req.Query["messageKey"].ToString();

                int qryBanner = int.Parse(req.Query["banner"].ToString());
                var banner = (Banner)qryBanner;

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var messaging = JsonConvert.DeserializeObject<Messaging>(requestBody);

                return await _salesForce.Send(messaging, banner, messageKey);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/Send method: {ex.Message}");
                throw;
            }
        }

        private Task<MessagingResponse> Send(Messaging messaging, Banner banner, string messageKey)
        {
            throw new NotImplementedException();
        }

        [FunctionName("SendEmail")]
        [OpenApiOperation(operationId: "SendEmail", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(MessageObject), Description = "", Required = true)]
        [OpenApiResponseWithoutBody(HttpStatusCode.OK)]
        public async Task<IActionResult> SendEmail(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/SendEmail")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/SendEmail request");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var messageObject = JsonConvert.DeserializeObject<MessageObject>(requestBody);

                //await new BusinessLogic.SalesForce(_cnf).SendEmail(messageObject);
                await _salesForce.SendEmail(messageObject);
                return new OkResult();
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/SendEmail method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("SendSms")]
        [OpenApiOperation(operationId: "SendSms", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SmsMessaging), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(SmsMessagingResponse))]
        public async Task<SmsMessagingResponse> SendSms(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/SendSms")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/SendSms request");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var smsMessaging = JsonConvert.DeserializeObject<SmsMessaging>(requestBody);

                return await _salesForce.SendSms(smsMessaging);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/SendSms method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("SendSMSQueue")]
        [OpenApiOperation(operationId: "SendSMSQueue", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SMSReminder), Description = "", Required = true)]
        [OpenApiResponseWithoutBody(HttpStatusCode.OK)]
        public async Task<IActionResult> SendSMSQueue(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/SendSMSQueue")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/SendSMSQueue request");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var smsReminder = JsonConvert.DeserializeObject<SMSReminder>(requestBody);

                await _salesForce.SendSMSQueue(smsReminder);
                return new OkResult();
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/SendSMSQueue method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("SalesForcePosMethodName")]
        [OpenApiOperation(operationId: "SalesForcePosMethodName", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SalesForceQueueRequest), Description = "", Required = true)]
        [OpenApiResponseWithoutBody(HttpStatusCode.OK)]
        public async Task<IActionResult> SalesForcePosMethodName(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/SalesForcePosMethodName")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/SalesForcePosMethodName request");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var salesForceQueueRequest = JsonConvert.DeserializeObject<SalesForceQueueRequest>(requestBody);

                await _salesForce.SalesForcePosMethodName(salesForceQueueRequest);
                return new OkResult();
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/SalesForcePosMethodName method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("WelcomeJourney")]
        [OpenApiOperation(operationId: "WelcomeJourney", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SEG.ApiService.Models.SalesForce.Data), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(WelcomeJourneyResponse))]
        public async Task<WelcomeJourneyResponse> WelcomeJourney(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/WelcomeJourney")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/WelcomeJourney request");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var welcomeData = JsonConvert.DeserializeObject<SEG.ApiService.Models.SalesForce.Data>(requestBody);

                return await _salesForce.WelcomeJourney(welcomeData);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/WelcomeJourney method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("WelcomeJourneyEcomm")]
        [OpenApiOperation(operationId: "WelcomeJourneyEcomm", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SEG.ApiService.Models.SalesForce.Data), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(WelcomeJourneyResponse))]
        public async Task<WelcomeJourneyResponse> WelcomeJourneyEcomm(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/WelcomeJourneyEcomm")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/WelcomeJourneyEcomm request");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var welcomeData = JsonConvert.DeserializeObject<SEG.ApiService.Models.SalesForce.Data>(requestBody);

                return await _salesForce.WelcomeJourneyEcomm(welcomeData);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/WelcomeJourneyEcomm method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("WelcomeJourneyBabyClub")]
        [OpenApiOperation(operationId: "WelcomeJourneyBabyClub", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SEG.ApiService.Models.SalesForce.Data), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(WelcomeJourneyResponse))]
        public async Task<WelcomeJourneyResponse> WelcomeJourneyBabyClub(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/WelcomeJourneyBabyClub")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/WelcomeJourneyBabyClub request");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var welcomeData = JsonConvert.DeserializeObject<SEG.ApiService.Models.SalesForce.Data>(requestBody);

                return await _salesForce.WelcomeJourneyBabyClub(welcomeData);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/WelcomeJourneyBabyClub method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("WelcomeJourneyPetClub")]
        [OpenApiOperation(operationId: "WelcomeJourneyPetClub", tags: new[] { "SalesForce" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SEG.ApiService.Models.SalesForce.Data), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(WelcomeJourneyResponse))]
        public async Task<WelcomeJourneyResponse> WelcomeJourneyPetClub(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "SalesForce/WelcomeJourneyPetClub")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SalesForce/WelcomeJourneyPetClub request");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var welcomeData = JsonConvert.DeserializeObject<SEG.ApiService.Models.SalesForce.Data>(requestBody);

                return await _salesForce.WelcomeJourneyPetClub(welcomeData);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SalesForce/WelcomeJourneyPetClub method: {ex.Message}");
                throw;
            }
        }

    }
}
