﻿using Microsoft.AspNetCore.Mvc;
using SalesForceLibrary.Models;
using SalesForceLibrary.SalesForceAPIM;
using SEG.ApiService.Models;
using SEG.ApiService.Models.Clubs;
using SEG.ApiService.Models.Enum;
using SEG.ApiService.Models.Loyalty;
using SEG.ApiService.Models.Payload;
using SEG.ApiService.Models.Request;
using SEG.ApiService.Models.SalesForce;
using SEG.ApiService.Models.SMS;
using SEG.LoyaltyService.Models.Results;
using SEG.SalesForce.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Collections;
using SEG;
using SEG.ApiService.Models.Pii;

namespace AzureLoyaltyFunctionApp.BusinessLogic
{
    public class Customer
    {
        private IDictionary _config;
        private SEG.CustomerLibrary.InternalCustomerController internalCustomerController;
        private SalesForceAPIMService salesForceService;
        private SEG.CustomerLibrary.CustomerService customerServiceAzure;
        //private SEG.CustomerLibrary.CustomerQueueProcess customerQueueProcess;
        private string salt;



        public Customer(IDictionary config)
        {
            _config = config;

            internalCustomerController = new SEG.CustomerLibrary.InternalCustomerController(
                _config["Settings__LoyaltyEndPoint"].ToString(),
                _config["SalesForce__ocpApimSubscriptionKey"].ToString());

            salesForceService = new SalesForceAPIMService(
                _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                _config["SalesForce__SEG_ClientID"].ToString(),
                _config["SalesForce__SEG_ClientSecret"].ToString(),
                _config["SalesForce__redisConnectionString"].ToString(),
                _config["SalesForce__ocpApimSubscriptionKey"].ToString());


            customerServiceAzure = new SEG.CustomerLibrary.CustomerService(
                _config["Settings__StoreWebAPIEndPoint"].ToString(),
                _config["Settings__LoyaltyEndPoint"].ToString(),
                _config["Settings__StorageConnectionString"].ToString(),
                _config["SalesForce__SalesForceAPIEndPoint"].ToString(),
                _config["SalesForce__ocpApimSubscriptionKey"].ToString());


            //var v1 = _config["Settings__StorageConnectionString"].ToString();
            ////var v2 = _config["Settings__AzureLoyaltyApiEndpoint"].ToString();
            //var v3 = _config["SalesForce__ocpApimSubscriptionKey"].ToString();


            //customerQueueProcess = new SEG.CustomerLibrary.CustomerQueueProcess(
            //    _config["Settings__StorageConnectionString"].ToString(),
            //    //_config["Settings__AzureLoyaltyApiEndpoint"].ToString(),
            //    null,
            //    _config["SalesForce__ocpApimSubscriptionKey"].ToString());


            salt = _config["Settings__EncryptedSalt"].ToString().DecryptStringAES2("LoyaltySalt");
            

        }



        //public async Task<PiiRequest> DeletePii(string memberId)
        //{
        //    salesForceService = new SalesForceAPIMService(
        //        _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
        //        _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
        //        _config["SEG_ClientID_delete"].ToString(),
        //        _config["SEG_ClientSecret_delete"].ToString(),
        //        _config["SalesForce__redisConnectionString"].ToString(),
        //        _config["SalesForce__ocpApimSubscriptionKey"].ToString());

        //    var response = new PiiRequest();

        //    if (!string.IsNullOrEmpty(memberId))
        //    {
        //        //Delete customer from CustODS
        //        response = await internalCustomerController.DeletePii(memberId).ConfigureAwait(false);

        //        if (response.Status == "Success")
        //        {
        //            //Delete contact from SFMC
        //            var result = await salesForceService.DeletePiiAsync(memberId).ConfigureAwait(false);

        //            //Deleting contact from SFMC failed
        //            if (result.HasErrors)
        //            {
        //                response.Status = "Fail";
        //                response.ErrorDescription = $"OperationId: { result.OperationId }, SFMC error: { string.Join(" ", result.ResultMessages) }";
        //            }
        //        }
        //    }

        //    return response;
        //}


        public async Task<PetClubResponse> UpsertPetClub(PetClubRequest petClubRequest)
        {
            List<PetClubChildItem> items = new List<PetClubChildItem>();
            PetClubResponse response = null;

            try
            {
                if (petClubRequest != null)
                {
                    response = await internalCustomerController.CustomerUpsertPetClub(petClubRequest).ConfigureAwait(false);

                    if (response.Status == "Success")
                    {
                        DataExtentionsPetClubChildRequest dataExtentionsPetClubChildRequest = new DataExtentionsPetClubChildRequest();
                        foreach (var i in petClubRequest.PetInfo)
                        {
                            PetClubChildItem item = new PetClubChildItem();
                            if (!string.IsNullOrEmpty(i.EnrollmentBanner))
                                item.EnrollmentBanner = i.EnrollmentBanner;
                            if (i.EnrollmentDate != null)
                                item.EnrollmentDate = i.EnrollmentDate.ToString();
                            if (!string.IsNullOrEmpty(i.EnrollmentSource))
                                item.EnrollementSource = i.EnrollmentSource;
                            if (!string.IsNullOrEmpty(i.LastUpdatedSource))
                                item.LAST_UPDATE_SOURCE = i.LastUpdatedSource;
                            if (i.LastUpdatedDate != null)
                                item.LAST_UPDATE_DT = i.LastUpdatedDate.ToString();
                            if (!string.IsNullOrEmpty(i.PetId))
                                item.PetID = i.PetId;
                            if (!string.IsNullOrEmpty(i.PetName))
                                item.PetName = i.PetName;
                            if (!string.IsNullOrEmpty(i.PetTypeId))
                                item.PetTypeID = i.PetTypeId;
                            if (!string.IsNullOrEmpty(i.PetTypeName))
                                item.PetTypeName = i.PetTypeName;

                            item.member_id = petClubRequest.MemberId;

                            items.Add(item);
                        }

                        dataExtentionsPetClubChildRequest.items = items;

                        var result = await salesForceService.UpsertAsyncPetClub(
                            dataExtentionsPetClubChildRequest,
                            petClubRequest.PetClubFlag,
                            petClubRequest.MemberId,
                            _config["SalesForce__SEG_Key"].ToString(),
                            _config["SalesForce__SEG_Key_PetClub"].ToString()
                            ).ConfigureAwait(false);
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception("Exception in UpsertPetClub :", e);
            }
            return response;

        }


        public async Task<BabyClubResponse> UpsertBabyClub(BabyClubRequest babyClubRequest)
        {
            List<BabyClubChildItem> items = new List<BabyClubChildItem>();
            BabyClubResponse response = null;

            try
            {

                if (babyClubRequest != null)
                {
                    response = await internalCustomerController.CustomerUpsertBabyClub(babyClubRequest).ConfigureAwait(false);

                    if (response.Status == "Success")
                    {
                        DataExtentionsBabyClubChildRequest dataExtentionsBabyClubChildRequest = new DataExtentionsBabyClubChildRequest();

                        foreach (var i in babyClubRequest.ChildInfo)
                        {
                            BabyClubChildItem item = new BabyClubChildItem();
                            if (!string.IsNullOrEmpty(i.AgedOutIndicator))
                                item.Aged_Out_Indicator = i.AgedOutIndicator;
                            if (i.BirthDate != null)
                                item.Birth_Date = i.BirthDate.ToString();
                            if (!string.IsNullOrEmpty(i.DeceasedIndicator))
                                item.Deceased_Indicator = i.DeceasedIndicator;
                            if (!string.IsNullOrEmpty(i.ExpectedBabyIndicator))
                                item.Expected_Baby_Indicator = i.ExpectedBabyIndicator;
                            if (!string.IsNullOrEmpty(i.FirstName))
                                item.First_Name = i.FirstName;
                            if (!string.IsNullOrEmpty(i.GenderCode))
                                item.Gender_Code = i.GenderCode;

                            item.Last_Name = i.LastName;

                            item.Member_ID = babyClubRequest.MemberId;
                            //child ID - child number .
                            if (i.ChildId != 0)
                            {
                                item.Member_Child_ID = string.Format("{0}_{1}", babyClubRequest.MemberId, i.ChildId.ToString());
                                item.Child_ID = i.ChildId.ToString();
                            }
                            if (!string.IsNullOrEmpty(i.MiddleInitial))
                                item.Middle_Initial = i.MiddleInitial.ToString();
                            if (!string.IsNullOrEmpty(i.SpecialNeedIndicator))
                                item.Special_Needs_Indicator = i.SpecialNeedIndicator.ToString();

                            items.Add(item);
                        }

                        dataExtentionsBabyClubChildRequest.items = items;

                        var result = await salesForceService.UpsertAsyncBabyClub(
                            dataExtentionsBabyClubChildRequest,
                            babyClubRequest.BabyClubFlag,
                            babyClubRequest.MemberId,
                            _config["SalesForce__SEG_Key"].ToString(),
                            _config["SalesForce__SEG_Key_BabyClub"].ToString())
                                .ConfigureAwait(false);
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception("Exception in UpsertBabyClub :", e);
            }
            return response;
        }


        public async Task<CustomerPreferenceUpsertResponse> UpsertEreceiptEnrollment(CustomerPreference customerPreference)
        {

            CustomerPreferenceUpsertResponse response;
            List<Item> list = new List<Item>();

            try
            {
                response = await internalCustomerController.SaveCustomerEReceiptPreference(customerPreference).ConfigureAwait(false);

                if (response.Status == "Success")
                {
                    DataExtentionsRequest dataExtentionRequest = new DataExtentionsRequest();
                    Item item = new Item();

                    item.MEMBER_ID = customerPreference.MemberID;
                    if (customerPreference.EReceiptEmailOptInStatus == true)
                    {
                        item.EReceipt_Email_OptIn_Status = "Y";
                    }
                    else
                    {
                        item.EReceipt_Email_OptIn_Status = "N";
                    }

                    if (customerPreference.EReceiptPaperLessOptInStatus == true)
                    {
                        item.EReceipt_Paperless_OptIn_Status = "Y";
                    }
                    else
                    {
                        item.EReceipt_Paperless_OptIn_Status = "N";
                    }

                    list.Add(item);
                    dataExtentionRequest.items = list;
                    DataExtentionsResponse dataExtentionsResponse = await salesForceService.UpsertAsync(dataExtentionRequest, _config["Settings:SalesForce:SEG_Key"].ToString()).ConfigureAwait(false);
                }
            }

            catch (Exception e)
            {
                throw new Exception("Exception in Upsert ERceiptEnrollment :", e);
            }
            return response;
        }


        //public async Task<bool> SaveCustomerInAzureEE(CustomerV2 customer, bool isSavePin = false, bool isSavePassword = false)
        //{
        //    try
        //    {
        //        //customer = await GetObjectFromPostDataIfNull<CustomerV2>(customer);

        //        customer.LastUpdateSource = customer.LastUpdateSource ?? "Azure";

        //        if (customer.CustomerAlias != null && customer.CustomerAlias.Count() > 0)
        //        {
        //            foreach (MemberAlias custAlias in customer.CustomerAlias)
        //            {
        //                //If we're saving this from Azure, and it's an Enrollment we can safely assume that this is an active card.. otherwise
        //                //the customer is wasting their time, and Omni has bigger problems by allowing this!
        //                if (custAlias.AliasStatus == null)
        //                    custAlias.AliasStatus = (short)AliasStatusType.Active;
        //            }
        //        }

        //        await customerServiceAzure.SaveCustomerInAzureWebEE(customer, false, isSavePin, isSavePassword);
        //    }
        //    catch (Exception e)
        //    {
        //        throw;
        //    }
        //    return true;
        //}


        //public async Task<IActionResult> CheckCustomerStatus(string loyaltyNumber)
        //{
        //    try
        //    {
        //        loyaltyNumber = loyaltyNumber?.Trim();

        //        var loyaltyCardResult = ProcessLoyaltyCard(loyaltyNumber);

        //        if (loyaltyCardResult == null) return new BadRequestObjectResult("Invalid Loyalty Number");

        //        switch (loyaltyCardResult.Item2)
        //        {
        //            case "WD":
        //            case "Bilo":
        //            case "Harveys":
        //            case "GnG":
        //            case "Plenti":
        //            case "Phone":
        //                return new OkObjectResult(await ValidateCustomer(loyaltyCardResult.Item1, loyaltyCardResult.Item2));
        //            default:
        //                return new BadRequestResult();
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        return new BadRequestObjectResult(e.ToString());
        //    }
        //}


        //public bool CheckPassword(CustomerCheckPassword customerCheckPassword)
        //{
        //    bool checkPassword = false;
        //    try
        //    {
        //        if (customerCheckPassword != null && !string.IsNullOrEmpty(customerCheckPassword.CurrentPassword) && !string.IsNullOrEmpty(customerCheckPassword.EncryptedPassword))
        //        {
        //            var password = $"{customerCheckPassword.CurrentPassword}{salt}".GenerateHashString(HashingExtensions.HashType.SHA256);

        //            if (customerCheckPassword.EncryptedPassword.Equals(password))
        //            {
        //                checkPassword = true;
        //            }
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        throw new Exception("Exception in CheckPassword :", e);
        //    }
        //    return checkPassword;
        //}


        public async Task<IActionResult> UpdateStoreInAzureEE(string MemberId, string ChainId, int StoreId, string lastUpdateSource)
        {
            StoreUpdateResult storeUpdateResult = null;
            try
            {
                storeUpdateResult = await customerServiceAzure.UpdateStoreInAzureEE(MemberId, ChainId, StoreId, lastUpdateSource).ConfigureAwait(false);
                await SFMCSelfSelectedStoreUpdate(storeUpdateResult).ConfigureAwait(false);
            }
            catch (Exception e)
            {
                return new BadRequestObjectResult(e.ToString());
            }
            return new OkObjectResult(storeUpdateResult);
        }


        //public async Task<bool> SendAuthCodebyPhoneNumber(SMSWebRequest smsWebRequest)
        //{
        //    bool result = false;

        //    try
        //    {
        //        var _authCode = smsWebRequest.AuthCode.DecryptStringAES(smsWebRequest.PhoneNumber, salt);
        //        var response = await customerServiceAzure.SendSMSAuthCode(smsWebRequest.PhoneNumber, _authCode, smsWebRequest.ChainId).ConfigureAwait(false);
        //        if (response.Equals("true"))
        //        {
        //            result = true;
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        throw;
        //    }
        //    return result;
        //}


        //public async Task<CustomerResponse> SendAuthorizationCodeToCustomer(
        //                                            CustomerSearchRequest searchRequest,
        //                                            string appCode,
        //                                            bool resetPassword,
        //                                            bool sendSMS,
        //                                            bool sendEmail,
        //                                            string templateType,
        //                                            string source,
        //                                            string authCode) => 
        //    await customerServiceAzure.SendAuthorizationCodeToCustomer(searchRequest, appCode, resetPassword,
        //                                                                sendSMS, sendEmail, templateType, source, authCode);


        //public async Task<string> GenerateGuid(GenerateGuidRequest generateGuidRequest) =>
        //     await customerServiceAzure.GenerateGuid(generateGuidRequest.TransactionID,
        //                                             generateGuidRequest.AppId,
        //                                             generateGuidRequest.AppVer,
        //                                             generateGuidRequest.MacAddress);


        //public async Task<string> InitApp(InitAppRequest initAppRequest) => 
        //            await customerServiceAzure.InitApp(initAppRequest.TransactionID,
        //                                            initAppRequest.AppId,
        //                                            initAppRequest.AppVer,
        //                                            initAppRequest.MacAddress,
        //                                            initAppRequest.DeviceId);


        //public async Task<IActionResult> ValidatePasswordEE(CredentialRequest credentialRequest)
        //{
        //    var response = new ApiResponse<CustomerV2>();
        //    int statusCode = 200;
        //    try
        //    {
        //        string chainId = new SEG.Shared.Utility().SetChainId(string.IsNullOrEmpty(credentialRequest.AppCode) ? "00" : credentialRequest.AppCode);

        //        CredRetrieveResultV2 credRetrieveResultV2 = await customerServiceAzure.ValidatePasswordV2(credentialRequest).ConfigureAwait(false);

        //        if (credRetrieveResultV2 == null)
        //        {
        //            Exception ex = new Exception("Internal Loyalty service error. Can not retrieve credentials for the user.");
        //            ex.Data.Add("code", "5001");
        //            throw ex;
        //        }
        //        if (String.IsNullOrEmpty(credRetrieveResultV2.status) || string.IsNullOrEmpty(credRetrieveResultV2.customer.MemberId) || credRetrieveResultV2.customer == null)
        //        {
        //            Exception ex = new Exception("User not found");
        //            ex.Data.Add("code", "5005");
        //            throw ex;
        //        }
        //        else if (credRetrieveResultV2.customer.EnrollmentStatus == null || credRetrieveResultV2.customer.EnrollmentStatus == "C")
        //        {
        //            Exception ex = new Exception("User is Cancelled");
        //            ex.Data.Add("code", "5007");
        //            throw ex;
        //        }
        //        else if (credRetrieveResultV2.status.ToLower().Equals("unauthenticated"))
        //        {
        //            UnauthorizedAccessException ex = new UnauthorizedAccessException("Authentication failed for the user");
        //            ex.Data.Add("code", "5002");
        //            throw ex;
        //        }
        //        else if (credRetrieveResultV2.status.ToLower().Equals("accountlockedout"))
        //        {
        //            Exception ex = new Exception("User Locked out");
        //            ex.Data.Add("code", "5003");
        //            throw ex;
        //        }
        //        else if (credRetrieveResultV2.status.ToLower().Equals("passwordnotset"))
        //        {
        //            Exception ex = new Exception("Password not set for the user");
        //            ex.Data.Add("code", "5006");
        //            throw ex;
        //        }
        //        else if (credRetrieveResultV2.status.ToLower().Equals("error") && credRetrieveResultV2.error_Description.Equals("User not found"))
        //        {
        //            Exception ex = new Exception("User not found");
        //            ex.Data.Add("code", "5005");
        //            throw ex;
        //        }
        //        else if (credRetrieveResultV2.error_Description != null)
        //        {
        //            Exception ex = new Exception(credRetrieveResultV2.error_Description);
        //            ex.Data.Add("code", "5004");
        //            throw ex;
        //        }
        //        else
        //        {
        //            if (credRetrieveResultV2.customer == null)
        //            {
        //                Exception ex = new Exception("User not found");
        //                ex.Data.Add("code", "5005");
        //                throw ex;
        //            }
        //            response.Object = credRetrieveResultV2.customer;
        //        }

        //    }
        //    catch (UnauthorizedAccessException e)
        //    {
        //        response.FaultMessage = new FaultDescriptor
        //        {
        //            Message = e.Message,
        //            Code = (e.Data["code"] != null) ? e.Data["code"].ToString() : "5000",
        //            RequestID = Guid.NewGuid().ToString()
        //        };

        //        statusCode = 401;
        //    }
        //    catch (Exception e)
        //    {
        //        //updated to 403 forbidden error . 
        //        response.FaultMessage = new FaultDescriptor
        //        {
        //            Message = e.Message,
        //            Code = (e.Data["code"] != null) ? e.Data["code"].ToString() : "5000",
        //            RequestID = Guid.NewGuid().ToString()
        //        };

        //        statusCode = 403;
        //    }
        //    var result = new ObjectResult(response) { StatusCode = statusCode };
        //    return result;
        //}


        public async Task<CustomerPreferenceUpsertResponse> SaveCustomerPreference(CustomerPreference customerPreference)
        {
            try
            {
                CustomerPreferenceUpsertResponse response = await internalCustomerController.SaveCustomerPreference(customerPreference).ConfigureAwait(false);

                if (response != null)
                {

                    #region Mapping
                    DataExtentionsCustomerPreferenceRequest dataExtentionsCustomerPreferenceRequest = new DataExtentionsCustomerPreferenceRequest();
                    dataExtentionsCustomerPreferenceRequest.items = new List<CustomerPreferenceItem>()
                    {
                        new CustomerPreferenceItem()
                        {
                            MemberID = customerPreference.MemberID,
                            Banner = customerPreference.Banner,
                            InterestDairyFree =  string.IsNullOrEmpty(customerPreference.InterestDairyFree.ToString()) ? null : customerPreference.InterestDairyFree.ToString(),
                            InterestGlutenFree = string.IsNullOrEmpty(customerPreference.InterestGlutenFree.ToString()) ? null : customerPreference.InterestGlutenFree.ToString(),
                            InterestGrilling =string.IsNullOrEmpty(customerPreference.InterestGrilling.ToString()) ? null : customerPreference.InterestGrilling.ToString(),
                            InterestGroceryDelivery = string.IsNullOrEmpty(customerPreference.InterestGroceryDelivery.ToString()) ? null : customerPreference.InterestGroceryDelivery.ToString(),
                            InterestHappyHour = string.IsNullOrEmpty(customerPreference.InterestHappyHour.ToString()) ? null : customerPreference.InterestHappyHour.ToString(),
                            InterestKidsBaby = string.IsNullOrEmpty(customerPreference.InterestKidsBaby.ToString()) ? null : customerPreference.InterestKidsBaby.ToString(),
                            InterestLowCarb = string.IsNullOrEmpty(customerPreference.InterestLowCarb.ToString()) ? null : customerPreference.InterestLowCarb.ToString(),
                            InterestOrganic = string.IsNullOrEmpty(customerPreference.InterestOrganic.ToString()) ? null : customerPreference.InterestOrganic.ToString(),
                            InterestPets = string.IsNullOrEmpty(customerPreference.InterestPets.ToString()) ? null : customerPreference.InterestPets.ToString(),
                            InterestRecipes = string.IsNullOrEmpty(customerPreference.InterestRecipes.ToString()) ? null : customerPreference.InterestRecipes.ToString(),
                            InterestSavings = string.IsNullOrEmpty(customerPreference.InterestSavings.ToString()) ? null : customerPreference.InterestSavings.ToString(),
                            InterestVegan = string.IsNullOrEmpty(customerPreference.InterestVegan.ToString()) ? null : customerPreference.InterestVegan.ToString(),
                            InterestVegetarian = string.IsNullOrEmpty(customerPreference.InterestVegetarian.ToString()) ? null : customerPreference.InterestVegetarian.ToString(),
                            EmailBirthdays = string.IsNullOrEmpty(customerPreference.EmailBirthdays.ToString()) ? null : customerPreference.EmailBirthdays.ToString(),
                            EmailSurveys = string.IsNullOrEmpty(customerPreference.EmailSurveys.ToString()) ? null : customerPreference.EmailSurveys.ToString(),
                            EmailWeekendSale = string.IsNullOrEmpty(customerPreference.EmailWeekendSale.ToString()) ? null : customerPreference.EmailWeekendSale.ToString(),
                            EmailWeeklyAds = string.IsNullOrEmpty(customerPreference.EmailWeeklyAds.ToString()) ? null : customerPreference.EmailWeeklyAds.ToString(),
                            OnlineShoppingVendor = customerPreference.OnlineShoppingVendor,
                            DisableBabyClubMessage = string.IsNullOrEmpty(customerPreference.DisableBabyClubMessage.ToString()) ? null : customerPreference.DisableBabyClubMessage.ToString(),
                        }
                    };
                    #endregion

                    DataExtentionsResponse dataExtentionsResponsePreference = await salesForceService.UpsertAsyncPreferences(
                                dataExtentionsCustomerPreferenceRequest,
                                _config["SalesForce__SEG_Key_CustomerPreferences"].ToString()).ConfigureAwait(false);

                    if (dataExtentionsResponsePreference == null || String.IsNullOrEmpty(dataExtentionsResponsePreference.requestId) || !string.IsNullOrEmpty(dataExtentionsResponsePreference.errorcode))
                        response.Status = "Error in Customer Preference SalesForce Upsert: " + dataExtentionsResponsePreference.message;
                }

                return response;
            }
            catch (Exception e)
            {
                throw new Exception("Exception in SaveCustomerPreference :", e);
            }
        }


        public async Task<CustomerPreferenceRetrieveResponse> GetPreference(string memberId, string chainId)
        {
            // will call from SEG library:
            // var results = await SEG.Shared.ApiUtility.RestfulCallAsync<CustomerPreferenceRetrieveResponse>(HttpMethod.Get, null, "api/Customer/GetPreference", BaseEndPoint, QueryParams: queryParams, Headers: createHeader()).ConfigureAwait(false);

            try
            {
                var result = await internalCustomerController.GetPreference(memberId, chainId);
                return result;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
                    




        #region Helpers

        private Tuple<string, string> ProcessLoyaltyCard(string loyaltyNumber)
        {
            try
            {
                string cardType = string.Empty;

                if (string.IsNullOrWhiteSpace(loyaltyNumber)) throw new ArgumentException("Invalid Loyalty Number");

                loyaltyNumber = loyaltyNumber.Trim();

                decimal.TryParse(loyaltyNumber, out decimal cardNumber);

                if (loyaltyNumber.Length == 12)
                {
                    loyaltyNumber = loyaltyNumber.Substring(0, 11);
                    decimal.TryParse(loyaltyNumber, out cardNumber);
                }
                else if (loyaltyNumber.StartsWith("9800"))
                {
                    if (cardNumber >= 980000000000000)
                        cardNumber = cardNumber - 980000000000000;

                }
                else if (loyaltyNumber.Length == 10)
                {
                    var regMatch = @"^([0-9]( |-)?)?(\(?[0-9]{3}\)?|[0-9]{3})( |-)?([0-9]{3}( |-)?[0-9]{4}|[a-zA-Z0-9]{7})$";
                    var reg = new Regex(regMatch);
                    var match = reg.Match(loyaltyNumber);
                    if (match != null && match.Success)
                    {
                        cardType = "Phone";
                    }

                    decimal.TryParse(loyaltyNumber, out cardNumber);

                }
                else if (loyaltyNumber.Length < 16)
                {
                    loyaltyNumber = loyaltyNumber.Substring(0, 11);
                    decimal.TryParse(loyaltyNumber, out cardNumber);
                }

                else if (loyaltyNumber.StartsWith("3104"))
                    cardType = "Plenti";
                else if (loyaltyNumber.StartsWith("72211"))
                    cardType = "GnG";


                if ((cardNumber < 42099999999 && cardNumber > 42065000000) ||
                    (cardNumber < 48199999999 && cardNumber > 48100000000))
                {
                    cardType = Banner.WD.ToString();
                }
                else if ((cardNumber < 44189999999 && cardNumber > 44000000000) ||
                         (cardNumber < 44999999999 && cardNumber > 44200000000) ||
                         (cardNumber < 48299999999 && cardNumber > 48200000000) ||
                         (cardNumber < 44199999999 && cardNumber > 44190000000))
                {
                    cardType = Banner.Bilo.ToString();
                }
                else if (
                     (cardNumber < 48399999999 && cardNumber > 48300000000) ||
                     (cardNumber < 44189999999 && cardNumber > 44000000000) ||
                     (cardNumber < 44999999999 && cardNumber > 44200000000))
                {
                    cardType = Banner.Harveys.ToString();
                }

                var formatControl = new System.Globalization.NumberFormatInfo
                {
                    NumberDecimalDigits = 0
                };
                if (string.IsNullOrEmpty(cardType)) return null;
                return new Tuple<string, string>(cardNumber.ToString(formatControl), cardType);
            }
            catch (Exception e)
            {
                throw;
            }
        }


        private async Task<ValidationResult> ValidateCustomer(string loyaltyNumber, string numberType)
        {
            try
            {
                var csr = new CustomerSearchRequest();
                AliasRequest gadRequest = null;
                ValidationResult validationResult = new ValidationResult
                {
                    LoyaltyCard = loyaltyNumber,
                    LoyaltyCardType = numberType,
                    EnrollmentStatus = "N",
                    swapped = false

                };


                switch (numberType)
                {
                    case "WD":
                        csr.CrcId = loyaltyNumber;
                        validationResult.Banner = Banner.WD;
                        break;
                    case "Bilo":
                        csr.CrcId = loyaltyNumber;
                        validationResult.Banner = Banner.Bilo;
                        break;
                    case "Harveys":
                        csr.CrcId = loyaltyNumber;
                        validationResult.Banner = Banner.Harveys;
                        break;
                    case "GnG":
                        csr.OmniId = loyaltyNumber;
                        break;
                    case "Plenti":
                        csr.OmniId = loyaltyNumber;
                        gadRequest = new AliasRequest
                        {
                            AliasType = AliasType.PlentiCardNumber,
                            Alias = loyaltyNumber
                        };
                        break;
                    case "Phone":
                        csr.MobilePhoneNumber = loyaltyNumber;
                        gadRequest = new AliasRequest
                        {
                            AliasType = AliasType.PhoneNumber,
                            Alias = loyaltyNumber
                        };
                        break;
                    default:
                        return null;

                }

                var icc = new SEG.CustomerLibrary.InternalCustomerController(
                    _config["Settings__LoyaltyEndPoint"].ToString(),
                    _config["SalesForce__ocpApimSubscriptionKey"].ToString());
                CustomerSearchResponse results = await icc.GetCustomerRecord(csr).ConfigureAwait(false);


                if (results != null && results.IsSuccessful && results.Customers.Any())
                {
                    validationResult.EnrollmentStatus = results.Customers.First().EnrollmentStatus ?? "P"; //Default Customer to Pre-Enrolled if Null
                    validationResult.MEMBER_ID = results.Customers.FirstOrDefault().MemberId;

                    if (results.Customers.First().CustomerAlias != null && results.Customers.First().CustomerAlias.Count > 0)
                    {
                        if (results.Customers.First().CustomerAlias.Any(a => a.AliasType == 2))
                        {
                            validationResult.swapped = true;
                        }
                    }
                }


                string[] validEnrollmentStatus = new string[] { "P", "N", "E" };


                if (!validEnrollmentStatus.Contains(validationResult.EnrollmentStatus))  //Any other result should default to Pre-Enrolled
                    validationResult.EnrollmentStatus = "P";

                return validationResult;
            }
            catch (Exception e)
            {
                throw new Exception("Exception in ValidateCustomer :", e);
            }
        }


        private async Task SFMCSelfSelectedStoreUpdate(StoreUpdateResult storeUpdateResult)
        {
            try
            {
                if (storeUpdateResult != null && storeUpdateResult.Success == "true")
                {
                    DataExtentionsRequest dataExtentionsRequest = new DataExtentionsRequest();
                    List<Item> list = new List<Item>();
                    Item item = new Item();

                    if (!string.IsNullOrEmpty(storeUpdateResult.MemberId) && !string.IsNullOrEmpty(storeUpdateResult.ChainId))
                    {
                        item.MEMBER_ID = storeUpdateResult.MemberId;

                        switch (storeUpdateResult.ChainId.Trim())
                        {
                            case "1":
                                item.Self_Selected_Store_WD = storeUpdateResult.StoreId;
                                break;
                            case "2":
                                item.Self_Selected_Store_BL = storeUpdateResult.StoreId;
                                break;
                            case "3":
                                item.Self_Selected_Store_HVY = storeUpdateResult.StoreId;
                                break;
                            case "4":
                                item.Self_Selected_Store_FYM = storeUpdateResult.StoreId;
                                break;
                            default:
                                break;
                        }

                        list.Add(item);
                        dataExtentionsRequest.items = list;

                        DataExtentionsResponse dataExtentionsResponse = await salesForceService.UpsertAsync(
                                        dataExtentionsRequest,
                                        _config["SalesForce__SEG_Key"].ToString()).ConfigureAwait(false);
                    }
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }


        #endregion


    }
}
