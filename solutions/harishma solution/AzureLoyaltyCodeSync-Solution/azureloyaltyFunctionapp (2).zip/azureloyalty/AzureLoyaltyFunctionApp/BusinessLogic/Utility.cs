﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using SEG.CustomerLibrary.Process;
using SEG.ApiService.Models.Offers;
using System.Collections;

namespace AzureLoyaltyFunctionApp.BusinessLogic
{
    public class Utility
    {

        IDictionary _config;

        public Utility(IDictionary config)
        {
            _config = config;
        }

        public async Task<IActionResult> GetEnrollmentOfferEE(string chainId)
        {
            try
            {
                OfferProcess offersProcess = new OfferProcess();

                if (string.IsNullOrEmpty(chainId))
                {
                    OfferFailureResponse error = new OfferFailureResponse()
                    {
                        ErrorCode = "400 Bad Request",
                        ErrorDescription = "Request cannot be null , ChainID is required "
                    };

                    return new BadRequestObjectResult(error);
                }

                //var dapperConnection = _config["Settings__LoyaltyConnection"].ToString();

                //Environment.SetEnvironmentVariable("LoyaltyConnection", dapperConnection);

                //SEG.AzureLoyaltyDatabase.DataAccess.DapperDalBase.ConnectionString = dapperConnection;

                string campaignId = await offersProcess.GetEnrollmentOfferEE(chainId).ConfigureAwait(false);

                return new OkObjectResult(campaignId);
            }
            catch (Exception ex)
            {
                throw new Exception("Exception in GetEnrollmentOfferEE :", ex);
            }
        }



    }
}
