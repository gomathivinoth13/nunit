﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SEG.SalesForce.Models;
using SalesForceLibrary.Models;
using SalesForceLibrary.Queue;
using SEG.ApiService.Models.SalesForce;
using SEG.ApiService.Models.SendGrid;
using SalesForceLibrary.SendSMSEmail;
using Polly;
using System.Net.Http;
using SEG.ApiService.Models.Utility;
using SEG.ApiService.Models.Enum;
using SEG.ApiService.Models.Reminder;
using SEG.ApiService.Models;
using SalesForceLibrary.SalesForceAPIM;
using System.Collections;
using SEG.ApiService.Models.Surveys;
using SEG.AzureLoyaltyDatabase;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SEG.ApiService.Models.Pii;
using SalesForceLibrary.SendJourney;

namespace AzureLoyaltyFunctionApp.BusinessLogic
{
    public class SalesForce
    {
        IDictionary _config;
        SalesForceAPIMService salesForceService;
        SalesForceQueueProcess salesForceQueueProcess;
        SalesForceSMSEmail salesForceSMSEmail;


        const string BiloBanner = "bi-lo";
        const string WinndixieBanner = "winn dixie";
        const string HarveysBanner = "harveys";
        const string FrescoBanner = "fresco y mas";

        public int RetryCount { get; set; }
        public int RetryWait { get; set; }

        public SalesForce(IDictionary config)
        {
            _config = config;
            RetryCount = Convert.ToInt32(_config["SalesForce__RetryCount"]);
            RetryWait = Convert.ToInt32(_config["SalesForce__RetryWait"]);
        }

        public async Task<ContactResponse> DeleteSFMCContact(string memberId)
        {
            //_config = cnf;
            var contactResponse = new ContactResponse();
            SalesForceAPIMService salesForceServiceDelete;
            //var env = Configuration["Settings:Environment"];
            salesForceServiceDelete = new SalesForceAPIMService(
                _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                _config["SEG_ClientID_delete"].ToString(),
                _config["SEG_ClientSecret_delete"].ToString(),
                _config["SalesForce__redisConnectionString"].ToString(),
                _config["SalesForce__ocpApimSubscriptionKey"].ToString());

            contactResponse = await salesForceServiceDelete.DeletePiiAsync(memberId).ConfigureAwait(false);

            // no condition for DEV environment because there's no SFMC DEV to delete from

            return contactResponse;
        }


        public async Task<DataExtentionsResponse> UpsertAsync(DataExtentionsRequestInsert dataExtentionsRequestInsert, bool opt_Out)
        {
            try
            {
                DataExtentionsResponse dataExtentionsResponse = null;

                //insert into master DE 
                if (dataExtentionsRequestInsert != null && dataExtentionsRequestInsert.dataExtentionsRequest != null && dataExtentionsRequestInsert.dataExtentionsRequest.items != null)
                {
                    if (dataExtentionsRequestInsert.dataExtentionsRequest.items.Count() > 0)
                    {
                        salesForceService = new SalesForceAPIMService(
                            _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                            _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                            _config["SalesForce__SEG_ClientID"].ToString(),
                            _config["SalesForce__SEG_ClientSecret"].ToString(),
                            _config["SalesForce__redisConnectionString"].ToString(),
                            _config["SalesForce__ocpApimSubscriptionKey"].ToString());

                        //if customer opt_ Out set to true . save them in staging environment . else save them in regular SEG BU . 
                        if (opt_Out)
                        {
                            dataExtentionsResponse = await Policy
                                .HandleResult<DataExtentionsResponse>(message => message == null || String.IsNullOrEmpty(message.requestId) || !string.IsNullOrEmpty(message.errorcode))
                                .WaitAndRetryAsync(RetryCount, i => TimeSpan.FromSeconds(RetryWait))
                                .ExecuteAsync(() => salesForceService.UpsertAsync(
                                    dataExtentionsRequestInsert.dataExtentionsRequest,
                                    _config["SalesForce__SEG_Key_Staging"].ToString()));
                        }
                        else
                        {
                            dataExtentionsResponse = await Policy
                                .HandleResult<DataExtentionsResponse>(message => message == null || String.IsNullOrEmpty(message.requestId) || !string.IsNullOrEmpty(message.errorcode))
                                .WaitAndRetryAsync(RetryCount, i => TimeSpan.FromSeconds(RetryWait))
                                .ExecuteAsync(() => salesForceService.UpsertAsync(
                                    dataExtentionsRequestInsert.dataExtentionsRequest,
                                    _config["SalesForce__SEG_Key"].ToString()));
                        }

                        if (dataExtentionsResponse == null || string.IsNullOrEmpty(dataExtentionsResponse.requestId) || !string.IsNullOrEmpty(dataExtentionsResponse.errorcode))
                        {
                            //* calling internal API to send email notifications
                            string json = SEG.Shared.Serializer.JsonSerialize<DataExtentionsRequest>(dataExtentionsRequestInsert.dataExtentionsRequest);
                            string subject = String.Format("SalesForce_Upsert failed to respond after Retry.");
                            await sendEmailInternally(json, subject, SEG.Shared.Serializer.JsonSerialize<DataExtentionsResponse>(dataExtentionsResponse)).ConfigureAwait(false);

                        }
                    }
                }

                return dataExtentionsResponse;
            }
            catch (Exception e)
            {
                throw new Exception("Exception in UpsertAsync :", e);
            }

        }


        public async Task QueueProcess(SalesForceQueueRequest salesForceQueueRequest)
        {
            try
            {
                salesForceQueueProcess = new SalesForceQueueProcess(
                    _config["SalesForce__SalesForceAPIEndPoint"].ToString());
                await salesForceQueueProcess.ProcessSalesForceRequest(salesForceQueueRequest).ConfigureAwait(false);
            }
            catch (Exception e)
            {
                throw new Exception("Exception in QueueProcess :", e);
            }
        }


        public async Task<MessagingResponse> Send(Messaging messaging, Banner banner, string messageKey)
        {
            try
            {
                salesForceService = setService(banner);
                MessagingResponse messagingResponse = await salesForceService.Send(messageKey, messaging).ConfigureAwait(false);
                return messagingResponse;
            }
            catch (Exception e)
            {
                throw new Exception("Exception in Send :", e);
            }
        }


        public async Task SendEmail(MessageObject messageObject)
        {
            try
            {
                salesForceSMSEmail = new SalesForceSMSEmail(_config["SalesForce__SalesForceAPIEndPoint"].ToString());
                await salesForceSMSEmail.SendEmail(messageObject).ConfigureAwait(false);
            }
            catch (Exception e)
            {
                throw new Exception("Exception in SendEmail :", e);
            }
        }


        public async Task<SmsMessagingResponse> SendSms(SmsMessaging messaging)
        {
            try
            {
                string messageKey;
                SmsMessagingResponse smsMessagingResponse = null;
                salesForceService = new SalesForceAPIMService(
                    _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                    _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                    _config["SalesForce__SEG_ClientID_SMS"].ToString(),
                    _config["SalesForce__SEG_ClientSecret_SMS"].ToString(),
                    _config["SalesForce__redisConnectionString"].ToString(),
                    _config["SalesForce__ocpApimSubscriptionKey"].ToString());

                if (messaging != null && !string.IsNullOrEmpty(messaging.keyword))
                {
                    if (messaging.keyword.ToLower() == SFMCKeywordType.RESETPW.ToString().ToLower())
                    {
                        messageKey = _config["SalesForce__KeywordRESETPW"].ToString();
                    }
                    else
                    {
                        messageKey = _config["SalesForce__KeywordAUTHORIZATIONCODE"].ToString();
                    }

                    smsMessagingResponse = await salesForceService.SendSMS(messageKey, messaging).ConfigureAwait(false);
                }
                return smsMessagingResponse;
            }
            catch (Exception e)
            {
                throw new Exception("Exception in SendSms :", e);
            }
        }


        public async Task SendSMSQueue(SMSReminder messageObject)
        {
            try
            {
                salesForceSMSEmail = new SalesForceSMSEmail(_config["SalesForce__SalesForceAPIEndPoint"].ToString());
                await salesForceSMSEmail.SendSMS(messageObject).ConfigureAwait(false);
            }
            catch (Exception e)
            {
                throw new Exception("Exception in SendSMSQueue :", e);
            }
        }


        public async Task SalesForcePosMethodName(SalesForceQueueRequest salesForceQueueRequest)
        {
            //_config = config;
            try
            {
                SalesForceJourney salesForceService = new SalesForceJourney(
                    _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                    _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                    _config["SEG_AccountID_POS"].ToString(),
                    _config["SEG_ClientID_POS"].ToString(),
                    _config["SEG_ClientSecret_POS"].ToString(),
                    _config["SalesForce__redisConnectionString"].ToString(),
                    _config["SalesForce__ocpApimSubscriptionKey"].ToString());

                await salesForceService.ProcessSalesForceRequest(salesForceQueueRequest.customer, salesForceQueueRequest.EventDefinitionKey, salesForceQueueRequest.StoreId);
            }
            catch (Exception ex)
            {
                throw new Exception("An error occured while trying to run Salesforce api SalesForcePosMethodName .  Error {0}",ex);
            }
        }


        public async Task<WelcomeJourneyResponse> WelcomeJourney(SEG.ApiService.Models.SalesForce.Data data)
        {
            try
            {
                WelcomeJourneyResponse welcomeJourneyResponse = null;

                if (data != null)
                {
                    WelcomeJourneyRequest welcomeJourneyRequest = new WelcomeJourneyRequest();
                    if (!string.IsNullOrEmpty(data.MEMBER_ID) && !string.IsNullOrEmpty(data.Enrollment_Banner))
                    {
                        welcomeJourneyRequest.ContactKey = data.MEMBER_ID;
                        welcomeJourneyRequest.EventDefinitionKey = setKey(data.Enrollment_Banner);
                        welcomeJourneyRequest.data = data;
                        salesForceService = setServiceJourney(data.Enrollment_Banner);

                        welcomeJourneyResponse = await salesForceService.WelcomeJourney(welcomeJourneyRequest).ConfigureAwait(false);
                    }
                }
                return welcomeJourneyResponse;
            }
            catch (Exception e)
            {
                throw new Exception("Exception in WelcomeJourney :", e);
            }
        }


        public async Task<WelcomeJourneyResponse> WelcomeJourneyEcomm(SEG.ApiService.Models.SalesForce.Data data)
        {
            try
            {
                WelcomeJourneyResponse welcomeJourneyResponse = null;

                if (data != null)
                {
                    WelcomeJourneyRequest welcomeJourneyRequest = new WelcomeJourneyRequest();
                    if (!string.IsNullOrEmpty(data.MEMBER_ID) && !string.IsNullOrEmpty(data.Enrollment_Banner))
                    {
                        welcomeJourneyRequest.ContactKey = data.MEMBER_ID;
                        welcomeJourneyRequest.EventDefinitionKey = setKeyEcomm(data.Enrollment_Banner);
                        welcomeJourneyRequest.data = data;
                        salesForceService = setServiceJourney(data.Enrollment_Banner);
                        welcomeJourneyResponse = await salesForceService.WelcomeJourney(welcomeJourneyRequest).ConfigureAwait(false);
                    }
                }
                return welcomeJourneyResponse;
            }
            catch (Exception e)
            {
                throw new Exception("Exception in WelcomeJourneyEcomm :", e);
            }
        }


        public async Task<WelcomeJourneyResponse> WelcomeJourneyBabyClub(SEG.ApiService.Models.SalesForce.Data data)
        {
            try
            {
                WelcomeJourneyResponse welcomeJourneyResponse = null;

                if (data != null)
                {
                    WelcomeJourneyRequest welcomeJourneyRequest = new WelcomeJourneyRequest();
                    if (!string.IsNullOrEmpty(data.MEMBER_ID) && !string.IsNullOrEmpty(data.Enrollment_Banner))
                    {
                        welcomeJourneyRequest.ContactKey = data.MEMBER_ID;
                        welcomeJourneyRequest.EventDefinitionKey = setKeyBabyClub(data.Enrollment_Banner);
                        welcomeJourneyRequest.data = data;
                        salesForceService = setServiceJourney(data.Enrollment_Banner);

                        welcomeJourneyResponse = await salesForceService.WelcomeJourney(welcomeJourneyRequest).ConfigureAwait(false);
                    }
                }
                return welcomeJourneyResponse;
            }
            catch (Exception e)
            {
                throw new Exception("Exception in WelcomeJourneyBabyClub :", e);
            }
        }


        public async Task<WelcomeJourneyResponse> WelcomeJourneyPetClub(SEG.ApiService.Models.SalesForce.Data data)
        {
            try
            {
                WelcomeJourneyResponse welcomeJourneyResponse = null;


                if (data != null)
                {
                    WelcomeJourneyRequest welcomeJourneyRequest = new WelcomeJourneyRequest();
                    if (!string.IsNullOrEmpty(data.MEMBER_ID) && !string.IsNullOrEmpty(data.Enrollment_Banner))
                    {
                        welcomeJourneyRequest.ContactKey = data.MEMBER_ID;
                        welcomeJourneyRequest.EventDefinitionKey = setKeyPetClub(data.Enrollment_Banner);
                        welcomeJourneyRequest.data = data;
                        salesForceService = setServiceJourney(data.Enrollment_Banner);

                        welcomeJourneyResponse = await salesForceService.WelcomeJourney(welcomeJourneyRequest).ConfigureAwait(false);
                    }
                }
                return welcomeJourneyResponse;
            }
            catch (Exception e)
            {
                throw new Exception("Exception in WelcomeJourneyPetClub :", e);
            }


        }


        public async Task<IActionResult> SaveProductSurveyAsync(ProductSurvey survey)
        {
            try
            {
                var isSaved = await AzureLoyaltyDatabaseManager.SaveProductSurveyAsync(survey);
                if (!isSaved) return new BadRequestResult();

                var response = await salesForceService.UpsertProductSurveyAsync(survey,
                                    _config["Settings:SalesForce:SEG_Key_Product_Survey"].ToString());

                if (string.IsNullOrEmpty(response.errorcode))
                    return new OkResult();
                return new BadRequestResult();
            }
            catch (Exception e)
            {
                throw new Exception("Exception in QueueProcess :", e);
            }
        }







        #region Helpers

        private async Task sendEmailInternally(string methodRequest, string subject, string methodResponse)
        {

            try
            {
                //* calling internal API to send email notifications
                InternalEmail internalEmail = new InternalEmail();


                var timeUtc = DateTime.UtcNow;
                var easternZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                internalEmail.errorResponse = string.Format("response {0} , Time : {1} ", methodResponse, TimeZoneInfo.ConvertTimeFromUtc(timeUtc, easternZone).ToString());
                internalEmail.methodRequest = methodRequest;
                internalEmail.subject = subject;
                internalEmail.toEmail = _config["SalesForce__MailAddressTo"].ToString();
                internalEmail.fromEmail = _config["SalesForce__MailAddressFrom"].ToString();
                internalEmail.ccEmail = _config["SalesForce__MailAddressCC"].ToString();

                await SEG.Shared.ApiUtility.RestfulCallAsync<string>(
                    HttpMethod.Post,
                    internalEmail,
                    "api/Utility/SendInternalEmail",
                    _config["Settings__LoyaltyEndPoint"].ToString(),
                    Headers: createHeader())
                        .ConfigureAwait(false);

            }
            catch (Exception e)
            {
                throw new Exception("Exception in sendEmailInternally :", e);
            }
        }


        private Dictionary<string, object> createHeader()
        {
            Dictionary<string, object> headers = new Dictionary<string, object>();

            headers.Add("Ocp-Apim-Subscription-Key", _config["Settings__SalesForce_ocpApimSubscriptionKey"].ToString());
            return headers;
        }


        private SalesForceAPIMService setService(Banner banner)
        {
            switch (banner)
            {
                case Banner.Harveys:
                    return new SalesForceAPIMService(
                        _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                        _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                        _config["SalesForce__Harveys_ClientID"].ToString(),
                        _config["SalesForce__Harveys_ClientSecret"].ToString(),
                        _config["SalesForce__redisConnectionString"].ToString(),
                        _config["SalesForce__ocpApimSubscriptionKey"].ToString());
                case Banner.WD:
                    return new SalesForceAPIMService(
                        _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                        _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                        _config["SalesForce__WinnDixie_ClientID"].ToString(),
                        _config["SalesForce__WinnDixie_ClientSecret"].ToString(),
                        _config["SalesForce__redisConnectionString"].ToString(),
                        _config["SalesForce__ocpApimSubscriptionKey"].ToString());
                case Banner.Fresco:
                    return new SalesForceAPIMService(
                        _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                        _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                        _config["SalesForce__Fresco_ClientID"].ToString(),
                        _config["SalesForce__Fresco_ClientSecret"].ToString(),
                        _config["SalesForce__redisConnectionString"].ToString(),
                        _config["SalesForce__ocpApimSubscriptionKey"].ToString());
                default:
                    return new SalesForceAPIMService(
                        _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                        _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                        _config["SalesForce__WinnDixie_ClientID"].ToString(),
                        _config["SalesForce__WinnDixie_ClientSecret"].ToString(),
                        _config["SalesForce__redisConnectionString"].ToString(),
                        _config["SalesForce__ocpApimSubscriptionKey"].ToString());
            }
        }


        private string setKey(string banner)
        {
            switch (banner.ToLower())
            {
                case HarveysBanner:
                    return _config["SalesForce__HarveysEventDefinitionKey"].ToString();
                case WinndixieBanner:
                    return _config["SalesForce__WDEventDefinitionKey"].ToString();
                case FrescoBanner:
                    return _config["SalesForce__FrescoEventDefinitionKey"].ToString();
                default:
                    return _config["SalesForce__WDEventDefinitionKey"].ToString();
            }
        }


        private SalesForceAPIMService setServiceJourney(string banner)
        {
            switch (banner.ToLower())
            {
                case HarveysBanner:
                    return new SalesForceAPIMService(
                        _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                        _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                        _config["SalesForce__Harveys_ClientID"].ToString(),
                        _config["SalesForce__Harveys_ClientSecret"].ToString(),
                        _config["SalesForce__redisConnectionString"].ToString(),
                        _config["SalesForce__ocpApimSubscriptionKey"].ToString());
                case WinndixieBanner:
                    return new SalesForceAPIMService(
                        _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                        _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                        _config["SalesForce__WinnDixie_ClientID"].ToString(),
                        _config["SalesForce__WinnDixie_ClientSecret"].ToString(),
                        _config["SalesForce__redisConnectionString"].ToString(),
                        _config["SalesForce__ocpApimSubscriptionKey"].ToString());
                case FrescoBanner:
                    return new SalesForceAPIMService(
                        _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                        _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                        _config["SalesForce__Fresco_ClientID"].ToString(),
                        _config["SalesForce__Fresco_ClientSecret"].ToString(),
                        _config["SalesForce__redisConnectionString"].ToString(),
                        _config["SalesForce__ocpApimSubscriptionKey"].ToString());
                default:
                    return new SalesForceAPIMService(
                        _config["SalesForce__SalesForceAPIMAuthEndPoint"].ToString(),
                        _config["SalesForce__SalesForceAPIMBaseEndPoint"].ToString(),
                        _config["SalesForce__WinnDixie_ClientID"].ToString(),
                        _config["SalesForce__WinnDixie_ClientSecret"].ToString(),
                        _config["SalesForce__redisConnectionString"].ToString(),
                        _config["SalesForce__ocpApimSubscriptionKey"].ToString());
            }
        }


        private string setKeyEcomm(string banner)
        {
            switch (banner.ToLower())
            {
                case HarveysBanner:
                    return _config["SalesForce__HarveysEcommEventDefinitionKey"].ToString();
                case WinndixieBanner:
                    return _config["SalesForce__WDEcommEventDefinitionKey"].ToString();
                case FrescoBanner:
                    return _config["SalesForce__FrescoEcommEventDefinitionKey"].ToString();
                default:
                    return _config["SalesForce__WDEcommEventDefinitionKey"].ToString();
            }
        }


        private string setKeyBabyClub(string banner)
        {
            switch (banner.ToLower())
            {
                case HarveysBanner:
                    return _config["SalesForce__HarveysBabyClubEventDefinitionKey"].ToString();
                case WinndixieBanner:
                    return _config["SalesForce__WDBabyClubEventDefinitionKey"].ToString();
                case FrescoBanner:
                    return _config["SalesForce__FrescoBabyClubEventDefinitionKey"].ToString();
                default:
                    return _config["SalesForce__WDBabyClubEventDefinitionKey"].ToString();
            }
        }


        private string setKeyPetClub(string banner)
        {
            switch (banner.ToLower())
            {
                case HarveysBanner:
                    return _config["SalesForce__HarveysPetClubEventDefinitionKey"].ToString();
                case WinndixieBanner:
                    return _config["SalesForce__WDPetClubEventDefinitionKey"].ToString();
                case FrescoBanner:
                    return _config["SalesForce__FrescoPetClubEventDefinitionKey"].ToString();
                default:
                    return _config["SalesForce__WDPetClubEventDefinitionKey"].ToString();
            }
        }

        #endregion


    }
}
