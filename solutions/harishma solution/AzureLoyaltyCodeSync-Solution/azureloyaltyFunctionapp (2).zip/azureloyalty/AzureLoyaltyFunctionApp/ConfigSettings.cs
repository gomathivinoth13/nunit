﻿using System;
using System.Collections;

namespace AzureLoyaltyFunctionApp
{
    public static class ConfigSettings
    {
        static IDictionary _config = null;
        public static IDictionary GetConfig()
        {
            if(_config == null)
                _config = Environment.GetEnvironmentVariables();

            return _config;
        }
    }
}
