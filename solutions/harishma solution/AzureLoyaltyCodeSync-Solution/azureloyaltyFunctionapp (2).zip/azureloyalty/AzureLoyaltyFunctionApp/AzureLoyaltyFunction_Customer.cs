﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections;
using SEG.ApiService.Models;
using SEG.ApiService.Models.Clubs;
using SEG.ApiService.Models.Request;
using SEG.ApiService.Models.SMS;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using System.Net;
using Microsoft.OpenApi.Models;
using SEG.ApiService.Models.Loyalty;
using SEG.ApiService.Models.Pii;
using AzureLoyaltyFunctionApp.BusinessLogic;
using Customer = AzureLoyaltyFunctionApp.BusinessLogic.Customer;

namespace AzureLoyaltyFunctionApp
{
    public class AzureLoyaltyFunction_Customer
    {
        static IDictionary _cnf = null;
        static AzureLoyaltyFunction_Customer()
        {
            _cnf = ConfigSettings.GetConfig();
        }
        private readonly Customer _customer = new Customer(_cnf);

        //[FunctionName("DeletePii")]
        //[OpenApiOperation(operationId: "Delete_Pii", tags: new[] { "Customer" }, Summary = "", Description = "")]
        ////[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        //[OpenApiParameter(name: "memberId", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(PiiRequest))]
        //public async Task<PiiRequest> DeletePii(
        //    [HttpTrigger(AuthorizationLevel.Anonymous, "delete", Route = "Customer/DeletePii")] HttpRequest req,
        //    ILogger log)
        //{
        //    try
        //    {
        //        log.LogInformation(".....Processing DeletePii request");
        //        string memberId = req.Query["memberId"].ToString();

        //        var response = await _customer.DeletePii(memberId);
        //        return response;
        //    }
        //    catch (Exception ex)
        //    {
        //        log.LogError($"Exception in DeletePii : {ex.Message}");
        //        throw;
        //    }
        //}


        [FunctionName("UpsertPetClub")]
        [OpenApiOperation(operationId: "Upsert_Pet_Club", tags: new[] { "Customer" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(PetClubRequest), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(PetClubResponse))]
        [OpenApiResponseWithBody(HttpStatusCode.BadRequest, contentType: "text/plain; charset=utf-8", typeof(string))]
        public async Task<IActionResult> UpsertPetClub(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/UpsertPetClub")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing UpsertPetClub request");
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();

                if (string.IsNullOrEmpty(requestBody))
                    return new BadRequestObjectResult("Request body cannot be empty");

                var request = JsonConvert.DeserializeObject<PetClubRequest>(requestBody);
                var response = _customer.UpsertPetClub(request).GetAwaiter().GetResult();
                return new OkObjectResult(response);

            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in UpsertPetClub method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("UpsertBabyClub")]
        [OpenApiOperation(operationId: "Upsert_Baby_Club", tags: new[] { "Customer" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(BabyClubRequest), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(BabyClubResponse))]
        [OpenApiResponseWithBody(HttpStatusCode.BadRequest, contentType: "text/plain; charset=utf-8", typeof(string))]
        public async Task<IActionResult> UpsertBabyClub(
        [HttpTrigger(AuthorizationLevel.Anonymous,"post", Route = "Customer/UpsertBabyClub")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing UpsertBabyClub request");
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();

                if (string.IsNullOrEmpty(requestBody))
                    return new BadRequestObjectResult("Request body cannot be empty");

                var request = JsonConvert.DeserializeObject<BabyClubRequest>(requestBody);
                var response = _customer.UpsertBabyClub(request).GetAwaiter().GetResult();
                return new OkObjectResult(response);

            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in UpsertBabyClub method: {ex.Message}");
                throw;
            }

        }


        [FunctionName("UpsertEreceiptEnrollment")]
        [OpenApiOperation(operationId: "Upsert_Ereceipt_Enrollment", tags: new[] { "Customer" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(CustomerPreference), Description = "", Required = true)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(CustomerPreferenceUpsertResponse))]
        public async Task<CustomerPreferenceUpsertResponse> UpsertEreceiptEnrollment(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/UpsertEreceiptEnrollment")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing UpsertEreceiptEnrollment request");
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();

                var request = JsonConvert.DeserializeObject<CustomerPreference>(requestBody);
                var response = _customer.UpsertEreceiptEnrollment(request).GetAwaiter().GetResult();
                return response;

            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in UpsertEreceiptEnrollment method: {ex.Message}");
                throw;
            }
        }


        //[FunctionName("SaveCustomerInAzureEE")]
        //[OpenApiOperation(operationId: "Save_Customer_In_Azure_EE", tags: new[] { "Customer" }, Summary = "", Description = "")]
        ////[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        //[OpenApiParameter(name: "isSavePin", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiParameter(name: "isSavePassword", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiRequestBody(contentType: "application/json", bodyType: typeof(CustomerV2), Description = "", Required = true)]
        //[OpenApiResponseWithoutBody(HttpStatusCode.OK)]
        //[OpenApiResponseWithBody(HttpStatusCode.BadRequest, contentType: "text/plain; charset=utf-8", typeof(string))]
        //public async Task<IActionResult> SaveCustomerInAzureEE(
        //[HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/SaveCustomerInAzureEE")] HttpRequest req,
        //ILogger log)
        //{
        //    try
        //    {
        //        log.LogInformation(".....Processing SaveCustomerInAzureEE request");

        //        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //        string qryIsSavePin = req.Query["isSavePin"].ToString();
        //        string qryIsSavePassword = req.Query["isSavePassword"].ToString();

        //        bool isSavePin = (qryIsSavePin == "1" || qryIsSavePin.ToUpper() == "TRUE");
        //        bool isSavePassword = (qryIsSavePassword == "1" || qryIsSavePassword.ToUpper() == "TRUE");

        //        if (string.IsNullOrEmpty(requestBody))
        //            return new BadRequestObjectResult("Request body cannot be empty");

        //        var request = JsonConvert.DeserializeObject<CustomerV2>(requestBody);
        //        var response = _customer
        //            .SaveCustomerInAzureEE(request, isSavePin, isSavePassword)
        //            .GetAwaiter().GetResult();
        //        return new OkResult();
        //    }
        //    catch (Exception ex)
        //    {
        //        log.LogError($"ERROR in SaveCustomerInAzureEE method: {ex.Message}");
        //        return new BadRequestObjectResult(ex.ToString());
        //    }
        //}


        //[FunctionName("CheckCustomerStatus")]
        //[OpenApiOperation(operationId: "Check_Customer_Status", tags: new[] { "Customer" }, Summary = "", Description = "")]
        ////[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        //[OpenApiParameter(name: "loyaltyNumber", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(ValidationResult))]
        //[OpenApiResponseWithBody(HttpStatusCode.BadRequest, contentType: "text/plain; charset=utf-8", typeof(string))]
        //public async Task<IActionResult> CheckCustomerStatus(
        //[HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/CheckCustomerStatus")] HttpRequest req,
        //ILogger log)
        //{
        //    try
        //    {
        //        log.LogInformation(".....Processing CheckCustomerStatus request");

        //        //string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //        string loyaltyNumber = req.Query["loyaltyNumber"].ToString();

        //        var result = await _customer.CheckCustomerStatus(loyaltyNumber);
        //        return new OkResult();
        //    }
        //    catch (Exception ex)
        //    {
        //        log.LogError($"ERROR in CheckCustomerStatus method: {ex.Message}");
        //        return new BadRequestObjectResult(ex.ToString());
        //    }
        //}


        //[FunctionName("CheckPassword")]
        //[OpenApiOperation(operationId: "Check_Password", tags: new[] { "Customer" }, Summary = "", Description = "")]
        ////[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        //[OpenApiRequestBody(contentType: "application/json", bodyType: typeof(CustomerCheckPassword), Description = "", Required = false)]
        //[OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(bool))]
        //public async Task<bool> CheckPassword(
        //[HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/CheckPassword")] HttpRequest req,
        //ILogger log)
        //{
        //    try
        //    {
        //        log.LogInformation(".....Processing CheckPassword request");
        //        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //        var request = JsonConvert.DeserializeObject<CustomerCheckPassword>(requestBody);
        //        var result = _customer.CheckPassword(request);
        //        return result;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw;
        //    }
        //}

        
        [FunctionName("UpdateStoreInAzureEE")]
        [OpenApiOperation(operationId: "Update_Store_In_AzureEE", tags: new[] { "Customer" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiParameter(name: "MemberId", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiParameter(name: "ChainId", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiParameter(name: "StoreId", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiParameter(name: "lastUpdateSource", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiResponseWithBody(HttpStatusCode.BadRequest, contentType: "text/plain; charset=utf-8", typeof(string))]
        [OpenApiResponseWithoutBody(HttpStatusCode.OK)]
        public async Task<IActionResult> UpdateStoreInAzureEE(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/UpdateStoreInAzureEE")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing UpdateStoreInAzureEE request");

                string memberId = req.Query["MemberId"].ToString();
                string chainId = req.Query["ChainId"].ToString();
                int storeId = int.Parse(req.Query["StoreId"].ToString());
                string lastUpdateSource = req.Query["lastUpdateSource"].ToString();

                return await _customer.UpdateStoreInAzureEE(memberId, chainId, storeId, lastUpdateSource);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in UpdateStoreInAzureEE method: {ex.Message}");
                return new BadRequestObjectResult(ex.ToString());
            }
        }


        //[FunctionName("SendAuthCodebyPhoneNumber")]
        //[OpenApiOperation(operationId: "Send_Auth_Code_byPhoneNumber", tags: new[] { "Customer" }, Summary = "", Description = "")]
        ////[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        //[OpenApiRequestBody(contentType: "application/json", bodyType: typeof(SMSWebRequest), Description = "", Required = false)]
        //[OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(bool))]
        //public async Task<bool> SendAuthCodebyPhoneNumber(
        //[HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/SendAuthCodebyPhoneNumber")] HttpRequest req,
        //ILogger log)
        //{
        //    try
        //    {
        //        log.LogInformation(".....Processing SendAuthCodebyPhoneNumber request");
        //        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //        var request = JsonConvert.DeserializeObject<SMSWebRequest>(requestBody);
        //        return _customer.SendAuthCodebyPhoneNumber(request).GetAwaiter().GetResult();
        //    }
        //    catch (Exception ex)
        //    {
        //        log.LogError($"ERROR in SendAuthCodebyPhoneNumber method: {ex.Message}");
        //        throw;
        //    }
        //}


        //[FunctionName("SendAuthorizationCodeToCustomer")]
        //[OpenApiOperation(operationId: "Send_Authorization_CodeToCustomer", tags: new[] { "Customer" }, Summary = "", Description = "")]
        ////[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        //[OpenApiParameter(name: "appCode", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiParameter(name: "sendEmail", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiParameter(name: "resetPassword", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiParameter(name: "sendSMS", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiParameter(name: "templateType", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiParameter(name: "source", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiParameter(name: "authCode", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        //[OpenApiRequestBody(contentType: "application/json", bodyType: typeof(CustomerSearchRequest), Description = "", Required = false)]
        //[OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(CustomerResponse))]
        //public async Task<CustomerResponse> SendAuthorizationCodeToCustomer(
        //[HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/SendAuthorizationCodeToCustomer")] HttpRequest req,
        //ILogger log)
        //{
        //    try
        //    {
        //        log.LogInformation(".....Processing SendAuthorizationCodeToCustomer request");

        //        string appCode = req.Query["appCode"].ToString();
        //        string qrySendEmail = req.Query["sendEmail"].ToString();
        //        bool sendEmail = (qrySendEmail == "1" || qrySendEmail.ToUpper() == "TRUE");

        //        string qryResetPassword = req.Query["resetPassword"].ToString();
        //        bool resetPassword = (qryResetPassword == "1" || qryResetPassword.ToUpper() == "TRUE");

        //        string qrySendSMS = req.Query["sendSMS"].ToString();
        //        bool sendSMS = (qrySendSMS == "1" || qrySendSMS.ToUpper() == "TRUE");

        //        string templateType = req.Query["templateType"].ToString();
        //        string source = req.Query["source"].ToString();
        //        string authCode = req.Query["authCode"].ToString();

        //        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //        var searchRequest = JsonConvert.DeserializeObject<CustomerSearchRequest>(requestBody);

        //        return await _customer
        //            .SendAuthorizationCodeToCustomer(searchRequest, appCode, resetPassword, sendSMS, sendEmail, templateType, source, authCode);
        //    }
        //    catch (Exception ex)
        //    {
        //        log.LogError($"ERROR in SendAuthorizationCodeToCustomer method: {ex.Message}");
        //        return null;
        //    }
        //}


        //[FunctionName("GenerateGuid")]
        //[OpenApiOperation(operationId: "Generate_Guid", tags: new[] { "Customer" }, Summary = "", Description = "")]
        ////[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        //[OpenApiRequestBody(contentType: "application/json", bodyType: typeof(GenerateGuidRequest), Description = "", Required = false)]
        //[OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(string))]
        //public async Task<string> GenerateGuid(
        //[HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/GenerateGuid")] HttpRequest req,
        //ILogger log)
        //{
        //    try
        //    {
        //        log.LogInformation(".....Processing GenerateGuid request");

        //        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //        var request = JsonConvert.DeserializeObject<GenerateGuidRequest>(requestBody);

        //        return await _customer
        //            .GenerateGuid(request);
        //    }
        //    catch (Exception ex)
        //    {
        //        log.LogError($"ERROR in GenerateGuid method: {ex.Message}");
        //        throw new Exception("Error in GenerateGuid method:", ex);
        //    }
        //}


        //[FunctionName("InitApp")]
        //[OpenApiOperation(operationId: "Init_App", tags: new[] { "Customer" }, Summary = "", Description = "")]
        ////[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        //[OpenApiRequestBody(contentType: "application/json", bodyType: typeof(InitAppRequest), Description = "", Required = false)]
        //[OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(string))]
        //public async Task<string> InitApp(
        //[HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/InitApp")] HttpRequest req,
        //ILogger log)
        //{
        //    try
        //    {
        //        log.LogInformation(".....Processing InitApp request");

        //        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //        var request = JsonConvert.DeserializeObject<InitAppRequest>(requestBody);

        //        return await _customer
        //            .InitApp(request);
        //    }
        //    catch (Exception ex)
        //    {
        //        log.LogError($"ERROR in InitApp method: {ex.Message}");
        //        throw new Exception("Error in InitApp method:", ex);
        //    }
        //}


        //[FunctionName("ValidatePasswordEE")]
        //[OpenApiOperation(operationId: "Validate_PasswordEE", tags: new[] { "Customer" }, Summary = "", Description = "")]
        ////[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        //[OpenApiRequestBody(contentType: "application/json", bodyType: typeof(CredentialRequest), Description = "", Required = false)]
        //[OpenApiResponseWithoutBody(HttpStatusCode.OK)]
        //public async Task<IActionResult> ValidatePasswordEE(
        //[HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/ValidatePasswordEE")] HttpRequest req,
        //ILogger log)
        //{
        //    try
        //    {
        //        log.LogInformation(".....Processing ValidatePasswordEE request");

        //        string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
        //        var request = JsonConvert.DeserializeObject<CredentialRequest>(requestBody);

        //        return await _customer
        //            .ValidatePasswordEE(request);
        //    }
        //    catch (Exception ex)
        //    {
        //        log.LogError($"ERROR in ValidatePasswordEE method: {ex.Message}");
        //        throw;
        //    }
        //}


        [FunctionName("SavePreference")]
        [OpenApiOperation(operationId: "Save_Preference", tags: new[] { "Customer" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(CustomerPreference), Description = "", Required = false)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(CustomerPreferenceUpsertResponse))]
        public async Task<CustomerPreferenceUpsertResponse> SavePreference(
        [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Customer/SavePreference")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing SavePreference request");

                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var request = JsonConvert.DeserializeObject<CustomerPreference>(requestBody);

                return await _customer
                    .SaveCustomerPreference(request);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in SavePreference method: {ex.Message}");
                throw;
            }
        }


        [FunctionName("GetPreference")]
        [OpenApiOperation(operationId: "Get_Preference", tags: new[] { "Customer" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiParameter(name: "memberId", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiParameter(name: "chainId", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(CustomerPreferenceRetrieveResponse))]
        public async Task<CustomerPreferenceRetrieveResponse> GetPreference(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "Customer/GetPreference")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing GetPreference request");

                string memberId = req.Query["memberId"].ToString();
                string chainId = req.Query["chainId"].ToString();

                return await _customer
                    .GetPreference(memberId, chainId);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in GetPreference method: {ex.Message}");
                throw new Exception(ex.Message);
            }
        }


        [FunctionName("GetConfig")]
        [OpenApiIgnore()]
        [OpenApiOperation(operationId: "Get_Config", tags: new[] { "Utility" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(string))]
        public static async Task<ActionResult> GetConfig(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "GetConfig")] HttpRequest req,
            ILogger log)
        {
            string key = req.Query["key"].ToString();

            return string.IsNullOrEmpty(key) ? new OkObjectResult(_cnf) : new OkObjectResult(_cnf[key]);
        }

    }
}


