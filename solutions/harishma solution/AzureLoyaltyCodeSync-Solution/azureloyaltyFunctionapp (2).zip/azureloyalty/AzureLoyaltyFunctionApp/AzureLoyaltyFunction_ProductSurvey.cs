﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using System.Net;
using Microsoft.OpenApi.Models;
using SEG.AzureLoyaltyDatabase;
using SEG.ApiService.Models.Surveys;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using System.Collections;

namespace AzureLoyaltyFunctionApp
{
    public static class AzureLoyaltyFunction_ProductSurvey
    {

        static IDictionary _cnf = null;
        static AzureLoyaltyFunction_ProductSurvey()
        {
            _cnf = ConfigSettings.GetConfig();
        }


        [FunctionName("GetProductSurvey")]
        [OpenApiOperation(operationId: "Get_Product_Survey", tags: new[] { "ProductSurvey" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiParameter(name: "memberId", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(string))]
        [OpenApiResponseWithBody(HttpStatusCode.BadRequest, contentType: "text/plain; charset=utf-8", typeof(string))]
        public static async Task<IActionResult> GetProductSurvey(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "Survey/GetProductSurvey")] HttpRequest req,
            ILogger log)
        {
            List<ProductSurvey> surveys = null;
            try
            {
                log.LogInformation(".....Processing Survey/GetProductSurvey request");

                string memberId = req.Query["memberId"].ToString();

                surveys = await AzureLoyaltyDatabaseManager.GetProductSurveyByMemberIdAsync(memberId);
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in Survey/GetProductSurvey method: {ex.Message}");
                throw new Exception("Exception in GetProductSurveyAsync :", ex);
            }
            return new OkObjectResult(surveys);
        }


        [FunctionName("SaveProductSurvey")]
        [OpenApiOperation(operationId: "Save_Product_Survey", tags: new[] { "ProductSurvey" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiRequestBody(contentType: "application/json", bodyType: typeof(ProductSurvey), Description = "", Required = false)]
        [OpenApiResponseWithoutBody(HttpStatusCode.OK)]
        [OpenApiResponseWithoutBody(HttpStatusCode.BadRequest)]
        public static async Task<IActionResult> SaveProductSurvey(
            [HttpTrigger(AuthorizationLevel.Anonymous, "post", Route = "Survey/SaveProductSurvey")] HttpRequest req,
            ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing Survey/SaveProductSurvey request");
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var survey = JsonConvert.DeserializeObject<ProductSurvey>(requestBody);

                if (survey == null) return new BadRequestResult();

                return await new BusinessLogic.SalesForce(_cnf).SaveProductSurveyAsync(survey);
            }
            catch (Exception e)
            {
                throw new Exception("Exception in Survey/SaveProductSurvey :", e);
            }
        }

    }
}
