﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Attributes;
using System.Net;
using Microsoft.OpenApi.Models;

namespace AzureLoyaltyFunctionApp
{
    public static class AzureLoyaltyFunction_Utility
    {
        [FunctionName("GetEnrollmentOfferEE")]
        [OpenApiOperation(operationId: "Get_Enrollment_OfferEE", tags: new[] { "Utility" }, Summary = "", Description = "")]
        //[OpenApiSecurity("function_key", SecuritySchemeType.ApiKey, Name = "x-functions-key", In = OpenApiSecurityLocationType.Header)]
        [OpenApiParameter(name: "chainId", In = ParameterLocation.Query, Required = true, Type = typeof(string))]
        [OpenApiResponseWithBody(HttpStatusCode.OK, contentType: "application/json", typeof(string))]
        [OpenApiResponseWithBody(HttpStatusCode.BadRequest, contentType: "text/plain; charset=utf-8", typeof(string))]
        public static async Task<IActionResult> GetEnrollmentOfferEE(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "Utility/GetEnrollmentOfferEE")] HttpRequest req,
        ILogger log)
        {
            try
            {
                log.LogInformation(".....Processing Utility/GetEnrollmentOfferEE request");

                string chainId = req.Query["chainId"].ToString();

                var result = new BusinessLogic.Utility(ConfigSettings.GetConfig()).GetEnrollmentOfferEE(chainId).GetAwaiter().GetResult();
                return result;
            }
            catch (Exception ex)
            {
                log.LogError($"ERROR in Utility/GetEnrollmentOfferEE method: {ex.Message}");
                return new BadRequestObjectResult(ex.ToString());
            }
        }

    }
}
