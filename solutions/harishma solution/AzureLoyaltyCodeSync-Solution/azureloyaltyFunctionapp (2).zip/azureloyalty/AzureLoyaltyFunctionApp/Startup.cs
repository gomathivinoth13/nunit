﻿using System;
using AzureLoyaltyFunctionApp;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Azure.WebJobs.Hosting;


[assembly: WebJobsStartup(typeof(Startup))]
namespace AzureLoyaltyFunctionApp
{
    public class Startup: FunctionsStartup
    {
        public Startup()
        {
        }

        public override void Configure(IFunctionsHostBuilder builder)
        {
            SEG.AzureLoyaltyDatabase.DataAccess.DapperDalBase.ConnectionString = Environment.GetEnvironmentVariable("Settings__LoyaltyConnection");
        }
        
    }
}





