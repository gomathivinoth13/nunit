﻿using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Configurations;
using Microsoft.OpenApi.Models;
using Microsoft.Azure.WebJobs.Extensions.OpenApi.Core.Enums;

namespace StoreLocatorFunctionApp
{
    public class OpenApiConfigurationOptions : DefaultOpenApiConfigurationOptions
    {
        public override OpenApiInfo Info { get; set; } = new OpenApiInfo()
        {
            Version = "1.0",
            Title = "Azure Loyalty Function App API"
        };

        public override OpenApiVersionType OpenApiVersion { get; set; } = OpenApiVersionType.V3;


    }
}